(() => {
  var __create = Object.create;
  var __defProp = Object.defineProperty;
  var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
  var __getOwnPropNames = Object.getOwnPropertyNames;
  var __getProtoOf = Object.getPrototypeOf;
  var __hasOwnProp = Object.prototype.hasOwnProperty;
  var __commonJS = (cb, mod) => function __require() {
    return mod || (0, cb[__getOwnPropNames(cb)[0]])((mod = { exports: {} }).exports, mod), mod.exports;
  };
  var __copyProps = (to, from, except, desc) => {
    if (from && typeof from === "object" || typeof from === "function") {
      for (let key of __getOwnPropNames(from))
        if (!__hasOwnProp.call(to, key) && key !== except)
          __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
    }
    return to;
  };
  var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
    // If the importer is in node compatibility mode or this is not an ESM
    // file that has been converted to a CommonJS file using a Babel-
    // compatible transform (i.e. "__esModule" has not been set), then set
    // "default" to the CommonJS "module.exports" for node compatibility.
    isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
    mod
  ));

  // node_modules/@mozilla/readability/Readability.js
  var require_Readability = __commonJS({
    "node_modules/@mozilla/readability/Readability.js"(exports, module) {
      function Readability2(doc, options) {
        if (options && options.documentElement) {
          doc = options;
          options = arguments[2];
        } else if (!doc || !doc.documentElement) {
          throw new Error(
            "First argument to Readability constructor should be a document object."
          );
        }
        options = options || {};
        this._doc = doc;
        this._docJSDOMParser = this._doc.firstChild.__JSDOMParser__;
        this._articleTitle = null;
        this._articleByline = null;
        this._articleDir = null;
        this._articleSiteName = null;
        this._attempts = [];
        this._metadata = {};
        this._debug = !!options.debug;
        this._maxElemsToParse = options.maxElemsToParse || this.DEFAULT_MAX_ELEMS_TO_PARSE;
        this._nbTopCandidates = options.nbTopCandidates || this.DEFAULT_N_TOP_CANDIDATES;
        this._charThreshold = options.charThreshold || this.DEFAULT_CHAR_THRESHOLD;
        this._classesToPreserve = this.CLASSES_TO_PRESERVE.concat(
          options.classesToPreserve || []
        );
        this._keepClasses = !!options.keepClasses;
        this._serializer = options.serializer || function(el) {
          return el.innerHTML;
        };
        this._disableJSONLD = !!options.disableJSONLD;
        this._allowedVideoRegex = options.allowedVideoRegex || this.REGEXPS.videos;
        this._linkDensityModifier = options.linkDensityModifier || 0;
        this._flags = this.FLAG_STRIP_UNLIKELYS | this.FLAG_WEIGHT_CLASSES | this.FLAG_CLEAN_CONDITIONALLY;
        if (this._debug) {
          let logNode = function(node) {
            if (node.nodeType == node.TEXT_NODE) {
              return `${node.nodeName} ("${node.textContent}")`;
            }
            let attrPairs = Array.from(node.attributes || [], function(attr) {
              return `${attr.name}="${attr.value}"`;
            }).join(" ");
            return `<${node.localName} ${attrPairs}>`;
          };
          this.log = function() {
            if (typeof console !== "undefined") {
              let args = Array.from(arguments, (arg) => {
                if (arg && arg.nodeType == this.ELEMENT_NODE) {
                  return logNode(arg);
                }
                return arg;
              });
              args.unshift("Reader: (Readability)");
              console.log(...args);
            } else if (typeof dump !== "undefined") {
              var msg = Array.prototype.map.call(arguments, function(x) {
                return x && x.nodeName ? logNode(x) : x;
              }).join(" ");
              dump("Reader: (Readability) " + msg + "\n");
            }
          };
        } else {
          this.log = function() {
          };
        }
      }
      Readability2.prototype = {
        FLAG_STRIP_UNLIKELYS: 1,
        FLAG_WEIGHT_CLASSES: 2,
        FLAG_CLEAN_CONDITIONALLY: 4,
        // https://developer.mozilla.org/en-US/docs/Web/API/Node/nodeType
        ELEMENT_NODE: 1,
        TEXT_NODE: 3,
        // Max number of nodes supported by this parser. Default: 0 (no limit)
        DEFAULT_MAX_ELEMS_TO_PARSE: 0,
        // The number of top candidates to consider when analysing how
        // tight the competition is among candidates.
        DEFAULT_N_TOP_CANDIDATES: 5,
        // Element tags to score by default.
        DEFAULT_TAGS_TO_SCORE: "section,h2,h3,h4,h5,h6,p,td,pre".toUpperCase().split(","),
        // The default number of chars an article must have in order to return a result
        DEFAULT_CHAR_THRESHOLD: 500,
        // All of the regular expressions in use within readability.
        // Defined up here so we don't instantiate them repeatedly in loops.
        REGEXPS: {
          // NOTE: These two regular expressions are duplicated in
          // Readability-readerable.js. Please keep both copies in sync.
          unlikelyCandidates: /-ad-|ai2html|banner|breadcrumbs|combx|comment|community|cover-wrap|disqus|extra|footer|gdpr|header|legends|menu|related|remark|replies|rss|shoutbox|sidebar|skyscraper|social|sponsor|supplemental|ad-break|agegate|pagination|pager|popup|yom-remote/i,
          okMaybeItsACandidate: /and|article|body|column|content|main|shadow/i,
          positive: /article|body|content|entry|hentry|h-entry|main|page|pagination|post|text|blog|story/i,
          negative: /-ad-|hidden|^hid$| hid$| hid |^hid |banner|combx|comment|com-|contact|footer|gdpr|masthead|media|meta|outbrain|promo|related|scroll|share|shoutbox|sidebar|skyscraper|sponsor|shopping|tags|widget/i,
          extraneous: /print|archive|comment|discuss|e[\-]?mail|share|reply|all|login|sign|single|utility/i,
          byline: /byline|author|dateline|writtenby|p-author/i,
          replaceFonts: /<(\/?)font[^>]*>/gi,
          normalize: /\s{2,}/g,
          videos: /\/\/(www\.)?((dailymotion|youtube|youtube-nocookie|player\.vimeo|v\.qq)\.com|(archive|upload\.wikimedia)\.org|player\.twitch\.tv)/i,
          shareElements: /(\b|_)(share|sharedaddy)(\b|_)/i,
          nextLink: /(next|weiter|continue|>([^\|]|$)|»([^\|]|$))/i,
          prevLink: /(prev|earl|old|new|<|«)/i,
          tokenize: /\W+/g,
          whitespace: /^\s*$/,
          hasContent: /\S$/,
          hashUrl: /^#.+/,
          srcsetUrl: /(\S+)(\s+[\d.]+[xw])?(\s*(?:,|$))/g,
          b64DataUrl: /^data:\s*([^\s;,]+)\s*;\s*base64\s*,/i,
          // Commas as used in Latin, Sindhi, Chinese and various other scripts.
          // see: https://en.wikipedia.org/wiki/Comma#Comma_variants
          commas: /\u002C|\u060C|\uFE50|\uFE10|\uFE11|\u2E41|\u2E34|\u2E32|\uFF0C/g,
          // See: https://schema.org/Article
          jsonLdArticleTypes: /^Article|AdvertiserContentArticle|NewsArticle|AnalysisNewsArticle|AskPublicNewsArticle|BackgroundNewsArticle|OpinionNewsArticle|ReportageNewsArticle|ReviewNewsArticle|Report|SatiricalArticle|ScholarlyArticle|MedicalScholarlyArticle|SocialMediaPosting|BlogPosting|LiveBlogPosting|DiscussionForumPosting|TechArticle|APIReference$/,
          // used to see if a node's content matches words commonly used for ad blocks or loading indicators
          adWords: /^(ad(vertising|vertisement)?|pub(licité)?|werb(ung)?|广告|Реклама|Anuncio)$/iu,
          loadingWords: /^((loading|正在加载|Загрузка|chargement|cargando)(…|\.\.\.)?)$/iu
        },
        UNLIKELY_ROLES: [
          "menu",
          "menubar",
          "complementary",
          "navigation",
          "alert",
          "alertdialog",
          "dialog"
        ],
        DIV_TO_P_ELEMS: /* @__PURE__ */ new Set([
          "BLOCKQUOTE",
          "DL",
          "DIV",
          "IMG",
          "OL",
          "P",
          "PRE",
          "TABLE",
          "UL"
        ]),
        ALTER_TO_DIV_EXCEPTIONS: ["DIV", "ARTICLE", "SECTION", "P", "OL", "UL"],
        PRESENTATIONAL_ATTRIBUTES: [
          "align",
          "background",
          "bgcolor",
          "border",
          "cellpadding",
          "cellspacing",
          "frame",
          "hspace",
          "rules",
          "style",
          "valign",
          "vspace"
        ],
        DEPRECATED_SIZE_ATTRIBUTE_ELEMS: ["TABLE", "TH", "TD", "HR", "PRE"],
        // The commented out elements qualify as phrasing content but tend to be
        // removed by readability when put into paragraphs, so we ignore them here.
        PHRASING_ELEMS: [
          // "CANVAS", "IFRAME", "SVG", "VIDEO",
          "ABBR",
          "AUDIO",
          "B",
          "BDO",
          "BR",
          "BUTTON",
          "CITE",
          "CODE",
          "DATA",
          "DATALIST",
          "DFN",
          "EM",
          "EMBED",
          "I",
          "IMG",
          "INPUT",
          "KBD",
          "LABEL",
          "MARK",
          "MATH",
          "METER",
          "NOSCRIPT",
          "OBJECT",
          "OUTPUT",
          "PROGRESS",
          "Q",
          "RUBY",
          "SAMP",
          "SCRIPT",
          "SELECT",
          "SMALL",
          "SPAN",
          "STRONG",
          "SUB",
          "SUP",
          "TEXTAREA",
          "TIME",
          "VAR",
          "WBR"
        ],
        // These are the classes that readability sets itself.
        CLASSES_TO_PRESERVE: ["page"],
        // These are the list of HTML entities that need to be escaped.
        HTML_ESCAPE_MAP: {
          lt: "<",
          gt: ">",
          amp: "&",
          quot: '"',
          apos: "'"
        },
        /**
         * Run any post-process modifications to article content as necessary.
         *
         * @param Element
         * @return void
         **/
        _postProcessContent(articleContent) {
          this._fixRelativeUris(articleContent);
          this._simplifyNestedElements(articleContent);
          if (!this._keepClasses) {
            this._cleanClasses(articleContent);
          }
        },
        /**
         * Iterates over a NodeList, calls `filterFn` for each node and removes node
         * if function returned `true`.
         *
         * If function is not passed, removes all the nodes in node list.
         *
         * @param NodeList nodeList The nodes to operate on
         * @param Function filterFn the function to use as a filter
         * @return void
         */
        _removeNodes(nodeList, filterFn) {
          if (this._docJSDOMParser && nodeList._isLiveNodeList) {
            throw new Error("Do not pass live node lists to _removeNodes");
          }
          for (var i = nodeList.length - 1; i >= 0; i--) {
            var node = nodeList[i];
            var parentNode = node.parentNode;
            if (parentNode) {
              if (!filterFn || filterFn.call(this, node, i, nodeList)) {
                parentNode.removeChild(node);
              }
            }
          }
        },
        /**
         * Iterates over a NodeList, and calls _setNodeTag for each node.
         *
         * @param NodeList nodeList The nodes to operate on
         * @param String newTagName the new tag name to use
         * @return void
         */
        _replaceNodeTags(nodeList, newTagName) {
          if (this._docJSDOMParser && nodeList._isLiveNodeList) {
            throw new Error("Do not pass live node lists to _replaceNodeTags");
          }
          for (const node of nodeList) {
            this._setNodeTag(node, newTagName);
          }
        },
        /**
         * Iterate over a NodeList, which doesn't natively fully implement the Array
         * interface.
         *
         * For convenience, the current object context is applied to the provided
         * iterate function.
         *
         * @param  NodeList nodeList The NodeList.
         * @param  Function fn       The iterate function.
         * @return void
         */
        _forEachNode(nodeList, fn) {
          Array.prototype.forEach.call(nodeList, fn, this);
        },
        /**
         * Iterate over a NodeList, and return the first node that passes
         * the supplied test function
         *
         * For convenience, the current object context is applied to the provided
         * test function.
         *
         * @param  NodeList nodeList The NodeList.
         * @param  Function fn       The test function.
         * @return void
         */
        _findNode(nodeList, fn) {
          return Array.prototype.find.call(nodeList, fn, this);
        },
        /**
         * Iterate over a NodeList, return true if any of the provided iterate
         * function calls returns true, false otherwise.
         *
         * For convenience, the current object context is applied to the
         * provided iterate function.
         *
         * @param  NodeList nodeList The NodeList.
         * @param  Function fn       The iterate function.
         * @return Boolean
         */
        _someNode(nodeList, fn) {
          return Array.prototype.some.call(nodeList, fn, this);
        },
        /**
         * Iterate over a NodeList, return true if all of the provided iterate
         * function calls return true, false otherwise.
         *
         * For convenience, the current object context is applied to the
         * provided iterate function.
         *
         * @param  NodeList nodeList The NodeList.
         * @param  Function fn       The iterate function.
         * @return Boolean
         */
        _everyNode(nodeList, fn) {
          return Array.prototype.every.call(nodeList, fn, this);
        },
        _getAllNodesWithTag(node, tagNames) {
          if (node.querySelectorAll) {
            return node.querySelectorAll(tagNames.join(","));
          }
          return [].concat.apply(
            [],
            tagNames.map(function(tag) {
              var collection = node.getElementsByTagName(tag);
              return Array.isArray(collection) ? collection : Array.from(collection);
            })
          );
        },
        /**
         * Removes the class="" attribute from every element in the given
         * subtree, except those that match CLASSES_TO_PRESERVE and
         * the classesToPreserve array from the options object.
         *
         * @param Element
         * @return void
         */
        _cleanClasses(node) {
          var classesToPreserve = this._classesToPreserve;
          var className = (node.getAttribute("class") || "").split(/\s+/).filter((cls) => classesToPreserve.includes(cls)).join(" ");
          if (className) {
            node.setAttribute("class", className);
          } else {
            node.removeAttribute("class");
          }
          for (node = node.firstElementChild; node; node = node.nextElementSibling) {
            this._cleanClasses(node);
          }
        },
        /**
         * Tests whether a string is a URL or not.
         *
         * @param {string} str The string to test
         * @return {boolean} true if str is a URL, false if not
         */
        _isUrl(str) {
          try {
            new URL(str);
            return true;
          } catch {
            return false;
          }
        },
        /**
         * Converts each <a> and <img> uri in the given element to an absolute URI,
         * ignoring #ref URIs.
         *
         * @param Element
         * @return void
         */
        _fixRelativeUris(articleContent) {
          var baseURI = this._doc.baseURI;
          var documentURI = this._doc.documentURI;
          function toAbsoluteURI(uri) {
            if (baseURI == documentURI && uri.charAt(0) == "#") {
              return uri;
            }
            try {
              return new URL(uri, baseURI).href;
            } catch (ex) {
            }
            return uri;
          }
          var links = this._getAllNodesWithTag(articleContent, ["a"]);
          this._forEachNode(links, function(link) {
            var href = link.getAttribute("href");
            if (href) {
              if (href.indexOf("javascript:") === 0) {
                if (link.childNodes.length === 1 && link.childNodes[0].nodeType === this.TEXT_NODE) {
                  var text = this._doc.createTextNode(link.textContent);
                  link.parentNode.replaceChild(text, link);
                } else {
                  var container = this._doc.createElement("span");
                  while (link.firstChild) {
                    container.appendChild(link.firstChild);
                  }
                  link.parentNode.replaceChild(container, link);
                }
              } else {
                link.setAttribute("href", toAbsoluteURI(href));
              }
            }
          });
          var medias = this._getAllNodesWithTag(articleContent, [
            "img",
            "picture",
            "figure",
            "video",
            "audio",
            "source"
          ]);
          this._forEachNode(medias, function(media) {
            var src = media.getAttribute("src");
            var poster = media.getAttribute("poster");
            var srcset = media.getAttribute("srcset");
            if (src) {
              media.setAttribute("src", toAbsoluteURI(src));
            }
            if (poster) {
              media.setAttribute("poster", toAbsoluteURI(poster));
            }
            if (srcset) {
              var newSrcset = srcset.replace(
                this.REGEXPS.srcsetUrl,
                function(_, p1, p2, p3) {
                  return toAbsoluteURI(p1) + (p2 || "") + p3;
                }
              );
              media.setAttribute("srcset", newSrcset);
            }
          });
        },
        _simplifyNestedElements(articleContent) {
          var node = articleContent;
          while (node) {
            if (node.parentNode && ["DIV", "SECTION"].includes(node.tagName) && !(node.id && node.id.startsWith("readability"))) {
              if (this._isElementWithoutContent(node)) {
                node = this._removeAndGetNext(node);
                continue;
              } else if (this._hasSingleTagInsideElement(node, "DIV") || this._hasSingleTagInsideElement(node, "SECTION")) {
                var child = node.children[0];
                for (var i = 0; i < node.attributes.length; i++) {
                  child.setAttributeNode(node.attributes[i].cloneNode());
                }
                node.parentNode.replaceChild(child, node);
                node = child;
                continue;
              }
            }
            node = this._getNextNode(node);
          }
        },
        /**
         * Get the article title as an H1.
         *
         * @return string
         **/
        _getArticleTitle() {
          var doc = this._doc;
          var curTitle = "";
          var origTitle = "";
          try {
            curTitle = origTitle = doc.title.trim();
            if (typeof curTitle !== "string") {
              curTitle = origTitle = this._getInnerText(
                doc.getElementsByTagName("title")[0]
              );
            }
          } catch (e) {
          }
          var titleHadHierarchicalSeparators = false;
          function wordCount(str) {
            return str.split(/\s+/).length;
          }
          if (/ [\|\-\\\/>»] /.test(curTitle)) {
            titleHadHierarchicalSeparators = / [\\\/>»] /.test(curTitle);
            let allSeparators = Array.from(origTitle.matchAll(/ [\|\-\\\/>»] /gi));
            curTitle = origTitle.substring(0, allSeparators.pop().index);
            if (wordCount(curTitle) < 3) {
              curTitle = origTitle.replace(/^[^\|\-\\\/>»]*[\|\-\\\/>»]/gi, "");
            }
          } else if (curTitle.includes(": ")) {
            var headings = this._getAllNodesWithTag(doc, ["h1", "h2"]);
            var trimmedTitle = curTitle.trim();
            var match = this._someNode(headings, function(heading) {
              return heading.textContent.trim() === trimmedTitle;
            });
            if (!match) {
              curTitle = origTitle.substring(origTitle.lastIndexOf(":") + 1);
              if (wordCount(curTitle) < 3) {
                curTitle = origTitle.substring(origTitle.indexOf(":") + 1);
              } else if (wordCount(origTitle.substr(0, origTitle.indexOf(":"))) > 5) {
                curTitle = origTitle;
              }
            }
          } else if (curTitle.length > 150 || curTitle.length < 15) {
            var hOnes = doc.getElementsByTagName("h1");
            if (hOnes.length === 1) {
              curTitle = this._getInnerText(hOnes[0]);
            }
          }
          curTitle = curTitle.trim().replace(this.REGEXPS.normalize, " ");
          var curTitleWordCount = wordCount(curTitle);
          if (curTitleWordCount <= 4 && (!titleHadHierarchicalSeparators || curTitleWordCount != wordCount(origTitle.replace(/[\|\-\\\/>»]+/g, "")) - 1)) {
            curTitle = origTitle;
          }
          return curTitle;
        },
        /**
         * Prepare the HTML document for readability to scrape it.
         * This includes things like stripping javascript, CSS, and handling terrible markup.
         *
         * @return void
         **/
        _prepDocument() {
          var doc = this._doc;
          this._removeNodes(this._getAllNodesWithTag(doc, ["style"]));
          if (doc.body) {
            this._replaceBrs(doc.body);
          }
          this._replaceNodeTags(this._getAllNodesWithTag(doc, ["font"]), "SPAN");
        },
        /**
         * Finds the next node, starting from the given node, and ignoring
         * whitespace in between. If the given node is an element, the same node is
         * returned.
         */
        _nextNode(node) {
          var next = node;
          while (next && next.nodeType != this.ELEMENT_NODE && this.REGEXPS.whitespace.test(next.textContent)) {
            next = next.nextSibling;
          }
          return next;
        },
        /**
         * Replaces 2 or more successive <br> elements with a single <p>.
         * Whitespace between <br> elements are ignored. For example:
         *   <div>foo<br>bar<br> <br><br>abc</div>
         * will become:
         *   <div>foo<br>bar<p>abc</p></div>
         */
        _replaceBrs(elem) {
          this._forEachNode(this._getAllNodesWithTag(elem, ["br"]), function(br) {
            var next = br.nextSibling;
            var replaced = false;
            while ((next = this._nextNode(next)) && next.tagName == "BR") {
              replaced = true;
              var brSibling = next.nextSibling;
              next.remove();
              next = brSibling;
            }
            if (replaced) {
              var p = this._doc.createElement("p");
              br.parentNode.replaceChild(p, br);
              next = p.nextSibling;
              while (next) {
                if (next.tagName == "BR") {
                  var nextElem = this._nextNode(next.nextSibling);
                  if (nextElem && nextElem.tagName == "BR") {
                    break;
                  }
                }
                if (!this._isPhrasingContent(next)) {
                  break;
                }
                var sibling = next.nextSibling;
                p.appendChild(next);
                next = sibling;
              }
              while (p.lastChild && this._isWhitespace(p.lastChild)) {
                p.lastChild.remove();
              }
              if (p.parentNode.tagName === "P") {
                this._setNodeTag(p.parentNode, "DIV");
              }
            }
          });
        },
        _setNodeTag(node, tag) {
          this.log("_setNodeTag", node, tag);
          if (this._docJSDOMParser) {
            node.localName = tag.toLowerCase();
            node.tagName = tag.toUpperCase();
            return node;
          }
          var replacement = node.ownerDocument.createElement(tag);
          while (node.firstChild) {
            replacement.appendChild(node.firstChild);
          }
          node.parentNode.replaceChild(replacement, node);
          if (node.readability) {
            replacement.readability = node.readability;
          }
          for (var i = 0; i < node.attributes.length; i++) {
            replacement.setAttributeNode(node.attributes[i].cloneNode());
          }
          return replacement;
        },
        /**
         * Prepare the article node for display. Clean out any inline styles,
         * iframes, forms, strip extraneous <p> tags, etc.
         *
         * @param Element
         * @return void
         **/
        _prepArticle(articleContent) {
          this._cleanStyles(articleContent);
          this._markDataTables(articleContent);
          this._fixLazyImages(articleContent);
          this._cleanConditionally(articleContent, "form");
          this._cleanConditionally(articleContent, "fieldset");
          this._clean(articleContent, "object");
          this._clean(articleContent, "embed");
          this._clean(articleContent, "footer");
          this._clean(articleContent, "link");
          this._clean(articleContent, "aside");
          var shareElementThreshold = this.DEFAULT_CHAR_THRESHOLD;
          this._forEachNode(articleContent.children, function(topCandidate) {
            this._cleanMatchedNodes(topCandidate, function(node, matchString) {
              return this.REGEXPS.shareElements.test(matchString) && node.textContent.length < shareElementThreshold;
            });
          });
          this._clean(articleContent, "iframe");
          this._clean(articleContent, "input");
          this._clean(articleContent, "textarea");
          this._clean(articleContent, "select");
          this._clean(articleContent, "button");
          this._cleanHeaders(articleContent);
          this._cleanConditionally(articleContent, "table");
          this._cleanConditionally(articleContent, "ul");
          this._cleanConditionally(articleContent, "div");
          this._replaceNodeTags(
            this._getAllNodesWithTag(articleContent, ["h1"]),
            "h2"
          );
          this._removeNodes(
            this._getAllNodesWithTag(articleContent, ["p"]),
            function(paragraph) {
              var contentElementCount = this._getAllNodesWithTag(paragraph, [
                "img",
                "embed",
                "object",
                "iframe"
              ]).length;
              return contentElementCount === 0 && !this._getInnerText(paragraph, false);
            }
          );
          this._forEachNode(
            this._getAllNodesWithTag(articleContent, ["br"]),
            function(br) {
              var next = this._nextNode(br.nextSibling);
              if (next && next.tagName == "P") {
                br.remove();
              }
            }
          );
          this._forEachNode(
            this._getAllNodesWithTag(articleContent, ["table"]),
            function(table) {
              var tbody = this._hasSingleTagInsideElement(table, "TBODY") ? table.firstElementChild : table;
              if (this._hasSingleTagInsideElement(tbody, "TR")) {
                var row = tbody.firstElementChild;
                if (this._hasSingleTagInsideElement(row, "TD")) {
                  var cell = row.firstElementChild;
                  cell = this._setNodeTag(
                    cell,
                    this._everyNode(cell.childNodes, this._isPhrasingContent) ? "P" : "DIV"
                  );
                  table.parentNode.replaceChild(cell, table);
                }
              }
            }
          );
        },
        /**
         * Initialize a node with the readability object. Also checks the
         * className/id for special names to add to its score.
         *
         * @param Element
         * @return void
         **/
        _initializeNode(node) {
          node.readability = { contentScore: 0 };
          switch (node.tagName) {
            case "DIV":
              node.readability.contentScore += 5;
              break;
            case "PRE":
            case "TD":
            case "BLOCKQUOTE":
              node.readability.contentScore += 3;
              break;
            case "ADDRESS":
            case "OL":
            case "UL":
            case "DL":
            case "DD":
            case "DT":
            case "LI":
            case "FORM":
              node.readability.contentScore -= 3;
              break;
            case "H1":
            case "H2":
            case "H3":
            case "H4":
            case "H5":
            case "H6":
            case "TH":
              node.readability.contentScore -= 5;
              break;
          }
          node.readability.contentScore += this._getClassWeight(node);
        },
        _removeAndGetNext(node) {
          var nextNode = this._getNextNode(node, true);
          node.remove();
          return nextNode;
        },
        /**
         * Traverse the DOM from node to node, starting at the node passed in.
         * Pass true for the second parameter to indicate this node itself
         * (and its kids) are going away, and we want the next node over.
         *
         * Calling this in a loop will traverse the DOM depth-first.
         *
         * @param {Element} node
         * @param {boolean} ignoreSelfAndKids
         * @return {Element}
         */
        _getNextNode(node, ignoreSelfAndKids) {
          if (!ignoreSelfAndKids && node.firstElementChild) {
            return node.firstElementChild;
          }
          if (node.nextElementSibling) {
            return node.nextElementSibling;
          }
          do {
            node = node.parentNode;
          } while (node && !node.nextElementSibling);
          return node && node.nextElementSibling;
        },
        // compares second text to first one
        // 1 = same text, 0 = completely different text
        // works the way that it splits both texts into words and then finds words that are unique in second text
        // the result is given by the lower length of unique parts
        _textSimilarity(textA, textB) {
          var tokensA = textA.toLowerCase().split(this.REGEXPS.tokenize).filter(Boolean);
          var tokensB = textB.toLowerCase().split(this.REGEXPS.tokenize).filter(Boolean);
          if (!tokensA.length || !tokensB.length) {
            return 0;
          }
          var uniqTokensB = tokensB.filter((token) => !tokensA.includes(token));
          var distanceB = uniqTokensB.join(" ").length / tokensB.join(" ").length;
          return 1 - distanceB;
        },
        /**
         * Checks whether an element node contains a valid byline
         *
         * @param node {Element}
         * @param matchString {string}
         * @return boolean
         */
        _isValidByline(node, matchString) {
          var rel = node.getAttribute("rel");
          var itemprop = node.getAttribute("itemprop");
          var bylineLength = node.textContent.trim().length;
          return (rel === "author" || itemprop && itemprop.includes("author") || this.REGEXPS.byline.test(matchString)) && !!bylineLength && bylineLength < 100;
        },
        _getNodeAncestors(node, maxDepth) {
          maxDepth = maxDepth || 0;
          var i = 0, ancestors = [];
          while (node.parentNode) {
            ancestors.push(node.parentNode);
            if (maxDepth && ++i === maxDepth) {
              break;
            }
            node = node.parentNode;
          }
          return ancestors;
        },
        /***
         * grabArticle - Using a variety of metrics (content score, classname, element types), find the content that is
         *         most likely to be the stuff a user wants to read. Then return it wrapped up in a div.
         *
         * @param page a document to run upon. Needs to be a full document, complete with body.
         * @return Element
         **/
        /* eslint-disable-next-line complexity */
        _grabArticle(page) {
          this.log("**** grabArticle ****");
          var doc = this._doc;
          var isPaging = page !== null;
          page = page ? page : this._doc.body;
          if (!page) {
            this.log("No body found in document. Abort.");
            return null;
          }
          var pageCacheHtml = page.innerHTML;
          while (true) {
            this.log("Starting grabArticle loop");
            var stripUnlikelyCandidates = this._flagIsActive(
              this.FLAG_STRIP_UNLIKELYS
            );
            var elementsToScore = [];
            var node = this._doc.documentElement;
            let shouldRemoveTitleHeader = true;
            while (node) {
              if (node.tagName === "HTML") {
                this._articleLang = node.getAttribute("lang");
              }
              var matchString = node.className + " " + node.id;
              if (!this._isProbablyVisible(node)) {
                this.log("Removing hidden node - " + matchString);
                node = this._removeAndGetNext(node);
                continue;
              }
              if (node.getAttribute("aria-modal") == "true" && node.getAttribute("role") == "dialog") {
                node = this._removeAndGetNext(node);
                continue;
              }
              if (!this._articleByline && !this._metadata.byline && this._isValidByline(node, matchString)) {
                var endOfSearchMarkerNode = this._getNextNode(node, true);
                var next = this._getNextNode(node);
                var itemPropNameNode = null;
                while (next && next != endOfSearchMarkerNode) {
                  var itemprop = next.getAttribute("itemprop");
                  if (itemprop && itemprop.includes("name")) {
                    itemPropNameNode = next;
                    break;
                  } else {
                    next = this._getNextNode(next);
                  }
                }
                this._articleByline = (itemPropNameNode ?? node).textContent.trim();
                node = this._removeAndGetNext(node);
                continue;
              }
              if (shouldRemoveTitleHeader && this._headerDuplicatesTitle(node)) {
                this.log(
                  "Removing header: ",
                  node.textContent.trim(),
                  this._articleTitle.trim()
                );
                shouldRemoveTitleHeader = false;
                node = this._removeAndGetNext(node);
                continue;
              }
              if (stripUnlikelyCandidates) {
                if (this.REGEXPS.unlikelyCandidates.test(matchString) && !this.REGEXPS.okMaybeItsACandidate.test(matchString) && !this._hasAncestorTag(node, "table") && !this._hasAncestorTag(node, "code") && node.tagName !== "BODY" && node.tagName !== "A") {
                  this.log("Removing unlikely candidate - " + matchString);
                  node = this._removeAndGetNext(node);
                  continue;
                }
                if (this.UNLIKELY_ROLES.includes(node.getAttribute("role"))) {
                  this.log(
                    "Removing content with role " + node.getAttribute("role") + " - " + matchString
                  );
                  node = this._removeAndGetNext(node);
                  continue;
                }
              }
              if ((node.tagName === "DIV" || node.tagName === "SECTION" || node.tagName === "HEADER" || node.tagName === "H1" || node.tagName === "H2" || node.tagName === "H3" || node.tagName === "H4" || node.tagName === "H5" || node.tagName === "H6") && this._isElementWithoutContent(node)) {
                node = this._removeAndGetNext(node);
                continue;
              }
              if (this.DEFAULT_TAGS_TO_SCORE.includes(node.tagName)) {
                elementsToScore.push(node);
              }
              if (node.tagName === "DIV") {
                var p = null;
                var childNode = node.firstChild;
                while (childNode) {
                  var nextSibling = childNode.nextSibling;
                  if (this._isPhrasingContent(childNode)) {
                    if (p !== null) {
                      p.appendChild(childNode);
                    } else if (!this._isWhitespace(childNode)) {
                      p = doc.createElement("p");
                      node.replaceChild(p, childNode);
                      p.appendChild(childNode);
                    }
                  } else if (p !== null) {
                    while (p.lastChild && this._isWhitespace(p.lastChild)) {
                      p.lastChild.remove();
                    }
                    p = null;
                  }
                  childNode = nextSibling;
                }
                if (this._hasSingleTagInsideElement(node, "P") && this._getLinkDensity(node) < 0.25) {
                  var newNode = node.children[0];
                  node.parentNode.replaceChild(newNode, node);
                  node = newNode;
                  elementsToScore.push(node);
                } else if (!this._hasChildBlockElement(node)) {
                  node = this._setNodeTag(node, "P");
                  elementsToScore.push(node);
                }
              }
              node = this._getNextNode(node);
            }
            var candidates = [];
            this._forEachNode(elementsToScore, function(elementToScore) {
              if (!elementToScore.parentNode || typeof elementToScore.parentNode.tagName === "undefined") {
                return;
              }
              var innerText = this._getInnerText(elementToScore);
              if (innerText.length < 25) {
                return;
              }
              var ancestors2 = this._getNodeAncestors(elementToScore, 5);
              if (ancestors2.length === 0) {
                return;
              }
              var contentScore = 0;
              contentScore += 1;
              contentScore += innerText.split(this.REGEXPS.commas).length;
              contentScore += Math.min(Math.floor(innerText.length / 100), 3);
              this._forEachNode(ancestors2, function(ancestor, level) {
                if (!ancestor.tagName || !ancestor.parentNode || typeof ancestor.parentNode.tagName === "undefined") {
                  return;
                }
                if (typeof ancestor.readability === "undefined") {
                  this._initializeNode(ancestor);
                  candidates.push(ancestor);
                }
                if (level === 0) {
                  var scoreDivider = 1;
                } else if (level === 1) {
                  scoreDivider = 2;
                } else {
                  scoreDivider = level * 3;
                }
                ancestor.readability.contentScore += contentScore / scoreDivider;
              });
            });
            var topCandidates = [];
            for (var c = 0, cl = candidates.length; c < cl; c += 1) {
              var candidate = candidates[c];
              var candidateScore = candidate.readability.contentScore * (1 - this._getLinkDensity(candidate));
              candidate.readability.contentScore = candidateScore;
              this.log("Candidate:", candidate, "with score " + candidateScore);
              for (var t = 0; t < this._nbTopCandidates; t++) {
                var aTopCandidate = topCandidates[t];
                if (!aTopCandidate || candidateScore > aTopCandidate.readability.contentScore) {
                  topCandidates.splice(t, 0, candidate);
                  if (topCandidates.length > this._nbTopCandidates) {
                    topCandidates.pop();
                  }
                  break;
                }
              }
            }
            var topCandidate = topCandidates[0] || null;
            var neededToCreateTopCandidate = false;
            var parentOfTopCandidate;
            if (topCandidate === null || topCandidate.tagName === "BODY") {
              topCandidate = doc.createElement("DIV");
              neededToCreateTopCandidate = true;
              while (page.firstChild) {
                this.log("Moving child out:", page.firstChild);
                topCandidate.appendChild(page.firstChild);
              }
              page.appendChild(topCandidate);
              this._initializeNode(topCandidate);
            } else if (topCandidate) {
              var alternativeCandidateAncestors = [];
              for (var i = 1; i < topCandidates.length; i++) {
                if (topCandidates[i].readability.contentScore / topCandidate.readability.contentScore >= 0.75) {
                  alternativeCandidateAncestors.push(
                    this._getNodeAncestors(topCandidates[i])
                  );
                }
              }
              var MINIMUM_TOPCANDIDATES = 3;
              if (alternativeCandidateAncestors.length >= MINIMUM_TOPCANDIDATES) {
                parentOfTopCandidate = topCandidate.parentNode;
                while (parentOfTopCandidate.tagName !== "BODY") {
                  var listsContainingThisAncestor = 0;
                  for (var ancestorIndex = 0; ancestorIndex < alternativeCandidateAncestors.length && listsContainingThisAncestor < MINIMUM_TOPCANDIDATES; ancestorIndex++) {
                    listsContainingThisAncestor += Number(
                      alternativeCandidateAncestors[ancestorIndex].includes(
                        parentOfTopCandidate
                      )
                    );
                  }
                  if (listsContainingThisAncestor >= MINIMUM_TOPCANDIDATES) {
                    topCandidate = parentOfTopCandidate;
                    break;
                  }
                  parentOfTopCandidate = parentOfTopCandidate.parentNode;
                }
              }
              if (!topCandidate.readability) {
                this._initializeNode(topCandidate);
              }
              parentOfTopCandidate = topCandidate.parentNode;
              var lastScore = topCandidate.readability.contentScore;
              var scoreThreshold = lastScore / 3;
              while (parentOfTopCandidate.tagName !== "BODY") {
                if (!parentOfTopCandidate.readability) {
                  parentOfTopCandidate = parentOfTopCandidate.parentNode;
                  continue;
                }
                var parentScore = parentOfTopCandidate.readability.contentScore;
                if (parentScore < scoreThreshold) {
                  break;
                }
                if (parentScore > lastScore) {
                  topCandidate = parentOfTopCandidate;
                  break;
                }
                lastScore = parentOfTopCandidate.readability.contentScore;
                parentOfTopCandidate = parentOfTopCandidate.parentNode;
              }
              parentOfTopCandidate = topCandidate.parentNode;
              while (parentOfTopCandidate.tagName != "BODY" && parentOfTopCandidate.children.length == 1) {
                topCandidate = parentOfTopCandidate;
                parentOfTopCandidate = topCandidate.parentNode;
              }
              if (!topCandidate.readability) {
                this._initializeNode(topCandidate);
              }
            }
            var articleContent = doc.createElement("DIV");
            if (isPaging) {
              articleContent.id = "readability-content";
            }
            var siblingScoreThreshold = Math.max(
              10,
              topCandidate.readability.contentScore * 0.2
            );
            parentOfTopCandidate = topCandidate.parentNode;
            var siblings = parentOfTopCandidate.children;
            for (var s = 0, sl = siblings.length; s < sl; s++) {
              var sibling = siblings[s];
              var append = false;
              this.log(
                "Looking at sibling node:",
                sibling,
                sibling.readability ? "with score " + sibling.readability.contentScore : ""
              );
              this.log(
                "Sibling has score",
                sibling.readability ? sibling.readability.contentScore : "Unknown"
              );
              if (sibling === topCandidate) {
                append = true;
              } else {
                var contentBonus = 0;
                if (sibling.className === topCandidate.className && topCandidate.className !== "") {
                  contentBonus += topCandidate.readability.contentScore * 0.2;
                }
                if (sibling.readability && sibling.readability.contentScore + contentBonus >= siblingScoreThreshold) {
                  append = true;
                } else if (sibling.nodeName === "P") {
                  var linkDensity = this._getLinkDensity(sibling);
                  var nodeContent = this._getInnerText(sibling);
                  var nodeLength = nodeContent.length;
                  if (nodeLength > 80 && linkDensity < 0.25) {
                    append = true;
                  } else if (nodeLength < 80 && nodeLength > 0 && linkDensity === 0 && nodeContent.search(/\.( |$)/) !== -1) {
                    append = true;
                  }
                }
              }
              if (append) {
                this.log("Appending node:", sibling);
                if (!this.ALTER_TO_DIV_EXCEPTIONS.includes(sibling.nodeName)) {
                  this.log("Altering sibling:", sibling, "to div.");
                  sibling = this._setNodeTag(sibling, "DIV");
                }
                articleContent.appendChild(sibling);
                siblings = parentOfTopCandidate.children;
                s -= 1;
                sl -= 1;
              }
            }
            if (this._debug) {
              this.log("Article content pre-prep: " + articleContent.innerHTML);
            }
            this._prepArticle(articleContent);
            if (this._debug) {
              this.log("Article content post-prep: " + articleContent.innerHTML);
            }
            if (neededToCreateTopCandidate) {
              topCandidate.id = "readability-page-1";
              topCandidate.className = "page";
            } else {
              var div = doc.createElement("DIV");
              div.id = "readability-page-1";
              div.className = "page";
              while (articleContent.firstChild) {
                div.appendChild(articleContent.firstChild);
              }
              articleContent.appendChild(div);
            }
            if (this._debug) {
              this.log("Article content after paging: " + articleContent.innerHTML);
            }
            var parseSuccessful = true;
            var textLength = this._getInnerText(articleContent, true).length;
            if (textLength < this._charThreshold) {
              parseSuccessful = false;
              page.innerHTML = pageCacheHtml;
              this._attempts.push({
                articleContent,
                textLength
              });
              if (this._flagIsActive(this.FLAG_STRIP_UNLIKELYS)) {
                this._removeFlag(this.FLAG_STRIP_UNLIKELYS);
              } else if (this._flagIsActive(this.FLAG_WEIGHT_CLASSES)) {
                this._removeFlag(this.FLAG_WEIGHT_CLASSES);
              } else if (this._flagIsActive(this.FLAG_CLEAN_CONDITIONALLY)) {
                this._removeFlag(this.FLAG_CLEAN_CONDITIONALLY);
              } else {
                this._attempts.sort(function(a, b) {
                  return b.textLength - a.textLength;
                });
                if (!this._attempts[0].textLength) {
                  return null;
                }
                articleContent = this._attempts[0].articleContent;
                parseSuccessful = true;
              }
            }
            if (parseSuccessful) {
              var ancestors = [parentOfTopCandidate, topCandidate].concat(
                this._getNodeAncestors(parentOfTopCandidate)
              );
              this._someNode(ancestors, function(ancestor) {
                if (!ancestor.tagName) {
                  return false;
                }
                var articleDir = ancestor.getAttribute("dir");
                if (articleDir) {
                  this._articleDir = articleDir;
                  return true;
                }
                return false;
              });
              return articleContent;
            }
          }
        },
        /**
         * Converts some of the common HTML entities in string to their corresponding characters.
         *
         * @param str {string} - a string to unescape.
         * @return string without HTML entity.
         */
        _unescapeHtmlEntities(str) {
          if (!str) {
            return str;
          }
          var htmlEscapeMap = this.HTML_ESCAPE_MAP;
          return str.replace(/&(quot|amp|apos|lt|gt);/g, function(_, tag) {
            return htmlEscapeMap[tag];
          }).replace(/&#(?:x([0-9a-f]+)|([0-9]+));/gi, function(_, hex, numStr) {
            var num = parseInt(hex || numStr, hex ? 16 : 10);
            if (num == 0 || num > 1114111 || num >= 55296 && num <= 57343) {
              num = 65533;
            }
            return String.fromCodePoint(num);
          });
        },
        /**
         * Try to extract metadata from JSON-LD object.
         * For now, only Schema.org objects of type Article or its subtypes are supported.
         * @return Object with any metadata that could be extracted (possibly none)
         */
        _getJSONLD(doc) {
          var scripts = this._getAllNodesWithTag(doc, ["script"]);
          var metadata;
          this._forEachNode(scripts, function(jsonLdElement) {
            if (!metadata && jsonLdElement.getAttribute("type") === "application/ld+json") {
              try {
                var content = jsonLdElement.textContent.replace(
                  /^\s*<!\[CDATA\[|\]\]>\s*$/g,
                  ""
                );
                var parsed = JSON.parse(content);
                if (Array.isArray(parsed)) {
                  parsed = parsed.find((it) => {
                    return it["@type"] && it["@type"].match(this.REGEXPS.jsonLdArticleTypes);
                  });
                  if (!parsed) {
                    return;
                  }
                }
                var schemaDotOrgRegex = /^https?\:\/\/schema\.org\/?$/;
                var matches = typeof parsed["@context"] === "string" && parsed["@context"].match(schemaDotOrgRegex) || typeof parsed["@context"] === "object" && typeof parsed["@context"]["@vocab"] == "string" && parsed["@context"]["@vocab"].match(schemaDotOrgRegex);
                if (!matches) {
                  return;
                }
                if (!parsed["@type"] && Array.isArray(parsed["@graph"])) {
                  parsed = parsed["@graph"].find((it) => {
                    return (it["@type"] || "").match(this.REGEXPS.jsonLdArticleTypes);
                  });
                }
                if (!parsed || !parsed["@type"] || !parsed["@type"].match(this.REGEXPS.jsonLdArticleTypes)) {
                  return;
                }
                metadata = {};
                if (typeof parsed.name === "string" && typeof parsed.headline === "string" && parsed.name !== parsed.headline) {
                  var title = this._getArticleTitle();
                  var nameMatches = this._textSimilarity(parsed.name, title) > 0.75;
                  var headlineMatches = this._textSimilarity(parsed.headline, title) > 0.75;
                  if (headlineMatches && !nameMatches) {
                    metadata.title = parsed.headline;
                  } else {
                    metadata.title = parsed.name;
                  }
                } else if (typeof parsed.name === "string") {
                  metadata.title = parsed.name.trim();
                } else if (typeof parsed.headline === "string") {
                  metadata.title = parsed.headline.trim();
                }
                if (parsed.author) {
                  if (typeof parsed.author.name === "string") {
                    metadata.byline = parsed.author.name.trim();
                  } else if (Array.isArray(parsed.author) && parsed.author[0] && typeof parsed.author[0].name === "string") {
                    metadata.byline = parsed.author.filter(function(author) {
                      return author && typeof author.name === "string";
                    }).map(function(author) {
                      return author.name.trim();
                    }).join(", ");
                  }
                }
                if (typeof parsed.description === "string") {
                  metadata.excerpt = parsed.description.trim();
                }
                if (parsed.publisher && typeof parsed.publisher.name === "string") {
                  metadata.siteName = parsed.publisher.name.trim();
                }
                if (typeof parsed.datePublished === "string") {
                  metadata.datePublished = parsed.datePublished.trim();
                }
              } catch (err) {
                this.log(err.message);
              }
            }
          });
          return metadata ? metadata : {};
        },
        /**
         * Attempts to get excerpt and byline metadata for the article.
         *
         * @param {Object} jsonld — object containing any metadata that
         * could be extracted from JSON-LD object.
         *
         * @return Object with optional "excerpt" and "byline" properties
         */
        _getArticleMetadata(jsonld) {
          var metadata = {};
          var values = {};
          var metaElements = this._doc.getElementsByTagName("meta");
          var propertyPattern = /\s*(article|dc|dcterm|og|twitter)\s*:\s*(author|creator|description|published_time|title|site_name)\s*/gi;
          var namePattern = /^\s*(?:(dc|dcterm|og|twitter|parsely|weibo:(article|webpage))\s*[-\.:]\s*)?(author|creator|pub-date|description|title|site_name)\s*$/i;
          this._forEachNode(metaElements, function(element) {
            var elementName = element.getAttribute("name");
            var elementProperty = element.getAttribute("property");
            var content = element.getAttribute("content");
            if (!content) {
              return;
            }
            var matches = null;
            var name = null;
            if (elementProperty) {
              matches = elementProperty.match(propertyPattern);
              if (matches) {
                name = matches[0].toLowerCase().replace(/\s/g, "");
                values[name] = content.trim();
              }
            }
            if (!matches && elementName && namePattern.test(elementName)) {
              name = elementName;
              if (content) {
                name = name.toLowerCase().replace(/\s/g, "").replace(/\./g, ":");
                values[name] = content.trim();
              }
            }
          });
          metadata.title = jsonld.title || values["dc:title"] || values["dcterm:title"] || values["og:title"] || values["weibo:article:title"] || values["weibo:webpage:title"] || values.title || values["twitter:title"] || values["parsely-title"];
          if (!metadata.title) {
            metadata.title = this._getArticleTitle();
          }
          const articleAuthor = typeof values["article:author"] === "string" && !this._isUrl(values["article:author"]) ? values["article:author"] : void 0;
          metadata.byline = jsonld.byline || values["dc:creator"] || values["dcterm:creator"] || values.author || values["parsely-author"] || articleAuthor;
          metadata.excerpt = jsonld.excerpt || values["dc:description"] || values["dcterm:description"] || values["og:description"] || values["weibo:article:description"] || values["weibo:webpage:description"] || values.description || values["twitter:description"];
          metadata.siteName = jsonld.siteName || values["og:site_name"];
          metadata.publishedTime = jsonld.datePublished || values["article:published_time"] || values["parsely-pub-date"] || null;
          metadata.title = this._unescapeHtmlEntities(metadata.title);
          metadata.byline = this._unescapeHtmlEntities(metadata.byline);
          metadata.excerpt = this._unescapeHtmlEntities(metadata.excerpt);
          metadata.siteName = this._unescapeHtmlEntities(metadata.siteName);
          metadata.publishedTime = this._unescapeHtmlEntities(metadata.publishedTime);
          return metadata;
        },
        /**
         * Check if node is image, or if node contains exactly only one image
         * whether as a direct child or as its descendants.
         *
         * @param Element
         **/
        _isSingleImage(node) {
          while (node) {
            if (node.tagName === "IMG") {
              return true;
            }
            if (node.children.length !== 1 || node.textContent.trim() !== "") {
              return false;
            }
            node = node.children[0];
          }
          return false;
        },
        /**
         * Find all <noscript> that are located after <img> nodes, and which contain only one
         * <img> element. Replace the first image with the image from inside the <noscript> tag,
         * and remove the <noscript> tag. This improves the quality of the images we use on
         * some sites (e.g. Medium).
         *
         * @param Element
         **/
        _unwrapNoscriptImages(doc) {
          var imgs = Array.from(doc.getElementsByTagName("img"));
          this._forEachNode(imgs, function(img) {
            for (var i = 0; i < img.attributes.length; i++) {
              var attr = img.attributes[i];
              switch (attr.name) {
                case "src":
                case "srcset":
                case "data-src":
                case "data-srcset":
                  return;
              }
              if (/\.(jpg|jpeg|png|webp)/i.test(attr.value)) {
                return;
              }
            }
            img.remove();
          });
          var noscripts = Array.from(doc.getElementsByTagName("noscript"));
          this._forEachNode(noscripts, function(noscript) {
            if (!this._isSingleImage(noscript)) {
              return;
            }
            var tmp = doc.createElement("div");
            tmp.innerHTML = noscript.innerHTML;
            var prevElement = noscript.previousElementSibling;
            if (prevElement && this._isSingleImage(prevElement)) {
              var prevImg = prevElement;
              if (prevImg.tagName !== "IMG") {
                prevImg = prevElement.getElementsByTagName("img")[0];
              }
              var newImg = tmp.getElementsByTagName("img")[0];
              for (var i = 0; i < prevImg.attributes.length; i++) {
                var attr = prevImg.attributes[i];
                if (attr.value === "") {
                  continue;
                }
                if (attr.name === "src" || attr.name === "srcset" || /\.(jpg|jpeg|png|webp)/i.test(attr.value)) {
                  if (newImg.getAttribute(attr.name) === attr.value) {
                    continue;
                  }
                  var attrName = attr.name;
                  if (newImg.hasAttribute(attrName)) {
                    attrName = "data-old-" + attrName;
                  }
                  newImg.setAttribute(attrName, attr.value);
                }
              }
              noscript.parentNode.replaceChild(tmp.firstElementChild, prevElement);
            }
          });
        },
        /**
         * Removes script tags from the document.
         *
         * @param Element
         **/
        _removeScripts(doc) {
          this._removeNodes(this._getAllNodesWithTag(doc, ["script", "noscript"]));
        },
        /**
         * Check if this node has only whitespace and a single element with given tag
         * Returns false if the DIV node contains non-empty text nodes
         * or if it contains no element with given tag or more than 1 element.
         *
         * @param Element
         * @param string tag of child element
         **/
        _hasSingleTagInsideElement(element, tag) {
          if (element.children.length != 1 || element.children[0].tagName !== tag) {
            return false;
          }
          return !this._someNode(element.childNodes, function(node) {
            return node.nodeType === this.TEXT_NODE && this.REGEXPS.hasContent.test(node.textContent);
          });
        },
        _isElementWithoutContent(node) {
          return node.nodeType === this.ELEMENT_NODE && !node.textContent.trim().length && (!node.children.length || node.children.length == node.getElementsByTagName("br").length + node.getElementsByTagName("hr").length);
        },
        /**
         * Determine whether element has any children block level elements.
         *
         * @param Element
         */
        _hasChildBlockElement(element) {
          return this._someNode(element.childNodes, function(node) {
            return this.DIV_TO_P_ELEMS.has(node.tagName) || this._hasChildBlockElement(node);
          });
        },
        /***
         * Determine if a node qualifies as phrasing content.
         * https://developer.mozilla.org/en-US/docs/Web/Guide/HTML/Content_categories#Phrasing_content
         **/
        _isPhrasingContent(node) {
          return node.nodeType === this.TEXT_NODE || this.PHRASING_ELEMS.includes(node.tagName) || (node.tagName === "A" || node.tagName === "DEL" || node.tagName === "INS") && this._everyNode(node.childNodes, this._isPhrasingContent);
        },
        _isWhitespace(node) {
          return node.nodeType === this.TEXT_NODE && node.textContent.trim().length === 0 || node.nodeType === this.ELEMENT_NODE && node.tagName === "BR";
        },
        /**
         * Get the inner text of a node - cross browser compatibly.
         * This also strips out any excess whitespace to be found.
         *
         * @param Element
         * @param Boolean normalizeSpaces (default: true)
         * @return string
         **/
        _getInnerText(e, normalizeSpaces) {
          normalizeSpaces = typeof normalizeSpaces === "undefined" ? true : normalizeSpaces;
          var textContent = e.textContent.trim();
          if (normalizeSpaces) {
            return textContent.replace(this.REGEXPS.normalize, " ");
          }
          return textContent;
        },
        /**
         * Get the number of times a string s appears in the node e.
         *
         * @param Element
         * @param string - what to split on. Default is ","
         * @return number (integer)
         **/
        _getCharCount(e, s) {
          s = s || ",";
          return this._getInnerText(e).split(s).length - 1;
        },
        /**
         * Remove the style attribute on every e and under.
         * TODO: Test if getElementsByTagName(*) is faster.
         *
         * @param Element
         * @return void
         **/
        _cleanStyles(e) {
          if (!e || e.tagName.toLowerCase() === "svg") {
            return;
          }
          for (var i = 0; i < this.PRESENTATIONAL_ATTRIBUTES.length; i++) {
            e.removeAttribute(this.PRESENTATIONAL_ATTRIBUTES[i]);
          }
          if (this.DEPRECATED_SIZE_ATTRIBUTE_ELEMS.includes(e.tagName)) {
            e.removeAttribute("width");
            e.removeAttribute("height");
          }
          var cur = e.firstElementChild;
          while (cur !== null) {
            this._cleanStyles(cur);
            cur = cur.nextElementSibling;
          }
        },
        /**
         * Get the density of links as a percentage of the content
         * This is the amount of text that is inside a link divided by the total text in the node.
         *
         * @param Element
         * @return number (float)
         **/
        _getLinkDensity(element) {
          var textLength = this._getInnerText(element).length;
          if (textLength === 0) {
            return 0;
          }
          var linkLength = 0;
          this._forEachNode(element.getElementsByTagName("a"), function(linkNode) {
            var href = linkNode.getAttribute("href");
            var coefficient = href && this.REGEXPS.hashUrl.test(href) ? 0.3 : 1;
            linkLength += this._getInnerText(linkNode).length * coefficient;
          });
          return linkLength / textLength;
        },
        /**
         * Get an elements class/id weight. Uses regular expressions to tell if this
         * element looks good or bad.
         *
         * @param Element
         * @return number (Integer)
         **/
        _getClassWeight(e) {
          if (!this._flagIsActive(this.FLAG_WEIGHT_CLASSES)) {
            return 0;
          }
          var weight = 0;
          if (typeof e.className === "string" && e.className !== "") {
            if (this.REGEXPS.negative.test(e.className)) {
              weight -= 25;
            }
            if (this.REGEXPS.positive.test(e.className)) {
              weight += 25;
            }
          }
          if (typeof e.id === "string" && e.id !== "") {
            if (this.REGEXPS.negative.test(e.id)) {
              weight -= 25;
            }
            if (this.REGEXPS.positive.test(e.id)) {
              weight += 25;
            }
          }
          return weight;
        },
        /**
         * Clean a node of all elements of type "tag".
         * (Unless it's a youtube/vimeo video. People love movies.)
         *
         * @param Element
         * @param string tag to clean
         * @return void
         **/
        _clean(e, tag) {
          var isEmbed = ["object", "embed", "iframe"].includes(tag);
          this._removeNodes(this._getAllNodesWithTag(e, [tag]), function(element) {
            if (isEmbed) {
              for (var i = 0; i < element.attributes.length; i++) {
                if (this._allowedVideoRegex.test(element.attributes[i].value)) {
                  return false;
                }
              }
              if (element.tagName === "object" && this._allowedVideoRegex.test(element.innerHTML)) {
                return false;
              }
            }
            return true;
          });
        },
        /**
         * Check if a given node has one of its ancestor tag name matching the
         * provided one.
         * @param  HTMLElement node
         * @param  String      tagName
         * @param  Number      maxDepth
         * @param  Function    filterFn a filter to invoke to determine whether this node 'counts'
         * @return Boolean
         */
        _hasAncestorTag(node, tagName, maxDepth, filterFn) {
          maxDepth = maxDepth || 3;
          tagName = tagName.toUpperCase();
          var depth = 0;
          while (node.parentNode) {
            if (maxDepth > 0 && depth > maxDepth) {
              return false;
            }
            if (node.parentNode.tagName === tagName && (!filterFn || filterFn(node.parentNode))) {
              return true;
            }
            node = node.parentNode;
            depth++;
          }
          return false;
        },
        /**
         * Return an object indicating how many rows and columns this table has.
         */
        _getRowAndColumnCount(table) {
          var rows = 0;
          var columns = 0;
          var trs = table.getElementsByTagName("tr");
          for (var i = 0; i < trs.length; i++) {
            var rowspan = trs[i].getAttribute("rowspan") || 0;
            if (rowspan) {
              rowspan = parseInt(rowspan, 10);
            }
            rows += rowspan || 1;
            var columnsInThisRow = 0;
            var cells = trs[i].getElementsByTagName("td");
            for (var j = 0; j < cells.length; j++) {
              var colspan = cells[j].getAttribute("colspan") || 0;
              if (colspan) {
                colspan = parseInt(colspan, 10);
              }
              columnsInThisRow += colspan || 1;
            }
            columns = Math.max(columns, columnsInThisRow);
          }
          return { rows, columns };
        },
        /**
         * Look for 'data' (as opposed to 'layout') tables, for which we use
         * similar checks as
         * https://searchfox.org/mozilla-central/rev/f82d5c549f046cb64ce5602bfd894b7ae807c8f8/accessible/generic/TableAccessible.cpp#19
         */
        _markDataTables(root) {
          var tables = root.getElementsByTagName("table");
          for (var i = 0; i < tables.length; i++) {
            var table = tables[i];
            var role = table.getAttribute("role");
            if (role == "presentation") {
              table._readabilityDataTable = false;
              continue;
            }
            var datatable = table.getAttribute("datatable");
            if (datatable == "0") {
              table._readabilityDataTable = false;
              continue;
            }
            var summary = table.getAttribute("summary");
            if (summary) {
              table._readabilityDataTable = true;
              continue;
            }
            var caption = table.getElementsByTagName("caption")[0];
            if (caption && caption.childNodes.length) {
              table._readabilityDataTable = true;
              continue;
            }
            var dataTableDescendants = ["col", "colgroup", "tfoot", "thead", "th"];
            var descendantExists = function(tag) {
              return !!table.getElementsByTagName(tag)[0];
            };
            if (dataTableDescendants.some(descendantExists)) {
              this.log("Data table because found data-y descendant");
              table._readabilityDataTable = true;
              continue;
            }
            if (table.getElementsByTagName("table")[0]) {
              table._readabilityDataTable = false;
              continue;
            }
            var sizeInfo = this._getRowAndColumnCount(table);
            if (sizeInfo.columns == 1 || sizeInfo.rows == 1) {
              table._readabilityDataTable = false;
              continue;
            }
            if (sizeInfo.rows >= 10 || sizeInfo.columns > 4) {
              table._readabilityDataTable = true;
              continue;
            }
            table._readabilityDataTable = sizeInfo.rows * sizeInfo.columns > 10;
          }
        },
        /* convert images and figures that have properties like data-src into images that can be loaded without JS */
        _fixLazyImages(root) {
          this._forEachNode(
            this._getAllNodesWithTag(root, ["img", "picture", "figure"]),
            function(elem) {
              if (elem.src && this.REGEXPS.b64DataUrl.test(elem.src)) {
                var parts = this.REGEXPS.b64DataUrl.exec(elem.src);
                if (parts[1] === "image/svg+xml") {
                  return;
                }
                var srcCouldBeRemoved = false;
                for (var i = 0; i < elem.attributes.length; i++) {
                  var attr = elem.attributes[i];
                  if (attr.name === "src") {
                    continue;
                  }
                  if (/\.(jpg|jpeg|png|webp)/i.test(attr.value)) {
                    srcCouldBeRemoved = true;
                    break;
                  }
                }
                if (srcCouldBeRemoved) {
                  var b64starts = parts[0].length;
                  var b64length = elem.src.length - b64starts;
                  if (b64length < 133) {
                    elem.removeAttribute("src");
                  }
                }
              }
              if ((elem.src || elem.srcset && elem.srcset != "null") && !elem.className.toLowerCase().includes("lazy")) {
                return;
              }
              for (var j = 0; j < elem.attributes.length; j++) {
                attr = elem.attributes[j];
                if (attr.name === "src" || attr.name === "srcset" || attr.name === "alt") {
                  continue;
                }
                var copyTo = null;
                if (/\.(jpg|jpeg|png|webp)\s+\d/.test(attr.value)) {
                  copyTo = "srcset";
                } else if (/^\s*\S+\.(jpg|jpeg|png|webp)\S*\s*$/.test(attr.value)) {
                  copyTo = "src";
                }
                if (copyTo) {
                  if (elem.tagName === "IMG" || elem.tagName === "PICTURE") {
                    elem.setAttribute(copyTo, attr.value);
                  } else if (elem.tagName === "FIGURE" && !this._getAllNodesWithTag(elem, ["img", "picture"]).length) {
                    var img = this._doc.createElement("img");
                    img.setAttribute(copyTo, attr.value);
                    elem.appendChild(img);
                  }
                }
              }
            }
          );
        },
        _getTextDensity(e, tags) {
          var textLength = this._getInnerText(e, true).length;
          if (textLength === 0) {
            return 0;
          }
          var childrenLength = 0;
          var children = this._getAllNodesWithTag(e, tags);
          this._forEachNode(
            children,
            (child) => childrenLength += this._getInnerText(child, true).length
          );
          return childrenLength / textLength;
        },
        /**
         * Clean an element of all tags of type "tag" if they look fishy.
         * "Fishy" is an algorithm based on content length, classnames, link density, number of images & embeds, etc.
         *
         * @return void
         **/
        _cleanConditionally(e, tag) {
          if (!this._flagIsActive(this.FLAG_CLEAN_CONDITIONALLY)) {
            return;
          }
          this._removeNodes(this._getAllNodesWithTag(e, [tag]), function(node) {
            var isDataTable = function(t) {
              return t._readabilityDataTable;
            };
            var isList = tag === "ul" || tag === "ol";
            if (!isList) {
              var listLength = 0;
              var listNodes = this._getAllNodesWithTag(node, ["ul", "ol"]);
              this._forEachNode(
                listNodes,
                (list) => listLength += this._getInnerText(list).length
              );
              isList = listLength / this._getInnerText(node).length > 0.9;
            }
            if (tag === "table" && isDataTable(node)) {
              return false;
            }
            if (this._hasAncestorTag(node, "table", -1, isDataTable)) {
              return false;
            }
            if (this._hasAncestorTag(node, "code")) {
              return false;
            }
            if ([...node.getElementsByTagName("table")].some(
              (tbl) => tbl._readabilityDataTable
            )) {
              return false;
            }
            var weight = this._getClassWeight(node);
            this.log("Cleaning Conditionally", node);
            var contentScore = 0;
            if (weight + contentScore < 0) {
              return true;
            }
            if (this._getCharCount(node, ",") < 10) {
              var p = node.getElementsByTagName("p").length;
              var img = node.getElementsByTagName("img").length;
              var li = node.getElementsByTagName("li").length - 100;
              var input = node.getElementsByTagName("input").length;
              var headingDensity = this._getTextDensity(node, [
                "h1",
                "h2",
                "h3",
                "h4",
                "h5",
                "h6"
              ]);
              var embedCount = 0;
              var embeds = this._getAllNodesWithTag(node, [
                "object",
                "embed",
                "iframe"
              ]);
              for (var i = 0; i < embeds.length; i++) {
                for (var j = 0; j < embeds[i].attributes.length; j++) {
                  if (this._allowedVideoRegex.test(embeds[i].attributes[j].value)) {
                    return false;
                  }
                }
                if (embeds[i].tagName === "object" && this._allowedVideoRegex.test(embeds[i].innerHTML)) {
                  return false;
                }
                embedCount++;
              }
              var innerText = this._getInnerText(node);
              if (this.REGEXPS.adWords.test(innerText) || this.REGEXPS.loadingWords.test(innerText)) {
                return true;
              }
              var contentLength = innerText.length;
              var linkDensity = this._getLinkDensity(node);
              var textishTags = ["SPAN", "LI", "TD"].concat(
                Array.from(this.DIV_TO_P_ELEMS)
              );
              var textDensity = this._getTextDensity(node, textishTags);
              var isFigureChild = this._hasAncestorTag(node, "figure");
              const shouldRemoveNode = () => {
                const errs = [];
                if (!isFigureChild && img > 1 && p / img < 0.5) {
                  errs.push(`Bad p to img ratio (img=${img}, p=${p})`);
                }
                if (!isList && li > p) {
                  errs.push(`Too many li's outside of a list. (li=${li} > p=${p})`);
                }
                if (input > Math.floor(p / 3)) {
                  errs.push(`Too many inputs per p. (input=${input}, p=${p})`);
                }
                if (!isList && !isFigureChild && headingDensity < 0.9 && contentLength < 25 && (img === 0 || img > 2) && linkDensity > 0) {
                  errs.push(
                    `Suspiciously short. (headingDensity=${headingDensity}, img=${img}, linkDensity=${linkDensity})`
                  );
                }
                if (!isList && weight < 25 && linkDensity > 0.2 + this._linkDensityModifier) {
                  errs.push(
                    `Low weight and a little linky. (linkDensity=${linkDensity})`
                  );
                }
                if (weight >= 25 && linkDensity > 0.5 + this._linkDensityModifier) {
                  errs.push(
                    `High weight and mostly links. (linkDensity=${linkDensity})`
                  );
                }
                if (embedCount === 1 && contentLength < 75 || embedCount > 1) {
                  errs.push(
                    `Suspicious embed. (embedCount=${embedCount}, contentLength=${contentLength})`
                  );
                }
                if (img === 0 && textDensity === 0) {
                  errs.push(
                    `No useful content. (img=${img}, textDensity=${textDensity})`
                  );
                }
                if (errs.length) {
                  this.log("Checks failed", errs);
                  return true;
                }
                return false;
              };
              var haveToRemove = shouldRemoveNode();
              if (isList && haveToRemove) {
                for (var x = 0; x < node.children.length; x++) {
                  let child = node.children[x];
                  if (child.children.length > 1) {
                    return haveToRemove;
                  }
                }
                let li_count = node.getElementsByTagName("li").length;
                if (img == li_count) {
                  return false;
                }
              }
              return haveToRemove;
            }
            return false;
          });
        },
        /**
         * Clean out elements that match the specified conditions
         *
         * @param Element
         * @param Function determines whether a node should be removed
         * @return void
         **/
        _cleanMatchedNodes(e, filter) {
          var endOfSearchMarkerNode = this._getNextNode(e, true);
          var next = this._getNextNode(e);
          while (next && next != endOfSearchMarkerNode) {
            if (filter.call(this, next, next.className + " " + next.id)) {
              next = this._removeAndGetNext(next);
            } else {
              next = this._getNextNode(next);
            }
          }
        },
        /**
         * Clean out spurious headers from an Element.
         *
         * @param Element
         * @return void
         **/
        _cleanHeaders(e) {
          let headingNodes = this._getAllNodesWithTag(e, ["h1", "h2"]);
          this._removeNodes(headingNodes, function(node) {
            let shouldRemove = this._getClassWeight(node) < 0;
            if (shouldRemove) {
              this.log("Removing header with low class weight:", node);
            }
            return shouldRemove;
          });
        },
        /**
         * Check if this node is an H1 or H2 element whose content is mostly
         * the same as the article title.
         *
         * @param Element  the node to check.
         * @return boolean indicating whether this is a title-like header.
         */
        _headerDuplicatesTitle(node) {
          if (node.tagName != "H1" && node.tagName != "H2") {
            return false;
          }
          var heading = this._getInnerText(node, false);
          this.log("Evaluating similarity of header:", heading, this._articleTitle);
          return this._textSimilarity(this._articleTitle, heading) > 0.75;
        },
        _flagIsActive(flag) {
          return (this._flags & flag) > 0;
        },
        _removeFlag(flag) {
          this._flags = this._flags & ~flag;
        },
        _isProbablyVisible(node) {
          return (!node.style || node.style.display != "none") && (!node.style || node.style.visibility != "hidden") && !node.hasAttribute("hidden") && //check for "fallback-image" so that wikimedia math images are displayed
          (!node.hasAttribute("aria-hidden") || node.getAttribute("aria-hidden") != "true" || node.className && node.className.includes && node.className.includes("fallback-image"));
        },
        /**
         * Runs readability.
         *
         * Workflow:
         *  1. Prep the document by removing script tags, css, etc.
         *  2. Build readability's DOM tree.
         *  3. Grab the article content from the current dom tree.
         *  4. Replace the current DOM tree with the new one.
         *  5. Read peacefully.
         *
         * @return void
         **/
        parse() {
          if (this._maxElemsToParse > 0) {
            var numTags = this._doc.getElementsByTagName("*").length;
            if (numTags > this._maxElemsToParse) {
              throw new Error(
                "Aborting parsing document; " + numTags + " elements found"
              );
            }
          }
          this._unwrapNoscriptImages(this._doc);
          var jsonLd = this._disableJSONLD ? {} : this._getJSONLD(this._doc);
          this._removeScripts(this._doc);
          this._prepDocument();
          var metadata = this._getArticleMetadata(jsonLd);
          this._metadata = metadata;
          this._articleTitle = metadata.title;
          var articleContent = this._grabArticle();
          if (!articleContent) {
            return null;
          }
          this.log("Grabbed: " + articleContent.innerHTML);
          this._postProcessContent(articleContent);
          if (!metadata.excerpt) {
            var paragraphs = articleContent.getElementsByTagName("p");
            if (paragraphs.length) {
              metadata.excerpt = paragraphs[0].textContent.trim();
            }
          }
          var textContent = articleContent.textContent;
          return {
            title: this._articleTitle,
            byline: metadata.byline || this._articleByline,
            dir: this._articleDir,
            lang: this._articleLang,
            content: this._serializer(articleContent),
            textContent,
            length: textContent.length,
            excerpt: metadata.excerpt,
            siteName: metadata.siteName || this._articleSiteName,
            publishedTime: metadata.publishedTime
          };
        }
      };
      if (typeof module === "object") {
        module.exports = Readability2;
      }
    }
  });

  // node_modules/@mozilla/readability/Readability-readerable.js
  var require_Readability_readerable = __commonJS({
    "node_modules/@mozilla/readability/Readability-readerable.js"(exports, module) {
      var REGEXPS = {
        // NOTE: These two regular expressions are duplicated in
        // Readability.js. Please keep both copies in sync.
        unlikelyCandidates: /-ad-|ai2html|banner|breadcrumbs|combx|comment|community|cover-wrap|disqus|extra|footer|gdpr|header|legends|menu|related|remark|replies|rss|shoutbox|sidebar|skyscraper|social|sponsor|supplemental|ad-break|agegate|pagination|pager|popup|yom-remote/i,
        okMaybeItsACandidate: /and|article|body|column|content|main|shadow/i
      };
      function isNodeVisible(node) {
        return (!node.style || node.style.display != "none") && !node.hasAttribute("hidden") && //check for "fallback-image" so that wikimedia math images are displayed
        (!node.hasAttribute("aria-hidden") || node.getAttribute("aria-hidden") != "true" || node.className && node.className.includes && node.className.includes("fallback-image"));
      }
      function isProbablyReaderable(doc, options = {}) {
        if (typeof options == "function") {
          options = { visibilityChecker: options };
        }
        var defaultOptions = {
          minScore: 20,
          minContentLength: 140,
          visibilityChecker: isNodeVisible
        };
        options = Object.assign(defaultOptions, options);
        var nodes = doc.querySelectorAll("p, pre, article");
        var brNodes = doc.querySelectorAll("div > br");
        if (brNodes.length) {
          var set = new Set(nodes);
          [].forEach.call(brNodes, function(node) {
            set.add(node.parentNode);
          });
          nodes = Array.from(set);
        }
        var score = 0;
        return [].some.call(nodes, function(node) {
          if (!options.visibilityChecker(node)) {
            return false;
          }
          var matchString = node.className + " " + node.id;
          if (REGEXPS.unlikelyCandidates.test(matchString) && !REGEXPS.okMaybeItsACandidate.test(matchString)) {
            return false;
          }
          if (node.matches("li p")) {
            return false;
          }
          var textContentLength = node.textContent.trim().length;
          if (textContentLength < options.minContentLength) {
            return false;
          }
          score += Math.sqrt(textContentLength - options.minContentLength);
          if (score > options.minScore) {
            return true;
          }
          return false;
        });
      }
      if (typeof module === "object") {
        module.exports = isProbablyReaderable;
      }
    }
  });

  // node_modules/@mozilla/readability/index.js
  var require_readability = __commonJS({
    "node_modules/@mozilla/readability/index.js"(exports, module) {
      var Readability2 = require_Readability();
      var isProbablyReaderable = require_Readability_readerable();
      module.exports = {
        Readability: Readability2,
        isProbablyReaderable
      };
    }
  });

  // src/content.js
  var import_readability = __toESM(require_readability(), 1);

  // src/content.css
  var content_default = ':host {\n  all: initial !important;\n}\n\n.sts-tooltip,\n.sts-popup {\n  --background: #fffcf0;\n  --surface: #fffcf0;\n  --surface-soft: #f2f0e5;\n  --border: #100f0f;\n  --border-muted: #cecdc3;\n  --text: #100f0f;\n  --muted: #6f6e69;\n  --primary: #100f0f;\n  --primary-hover: #343331;\n  --danger: #af3029;\n  --ease: cubic-bezier(0.2, 0, 0.4, 1);\n  --font: ui-monospace, "SF Mono", Menlo, Consolas, monospace;\n  scrollbar-color: var(--muted) var(--surface);\n  scrollbar-width: thin;\n}\n\n.sts-tooltip,\n.sts-tooltip *,\n.sts-popup,\n.sts-popup * {\n  box-sizing: border-box;\n  font-family: var(--font) !important;\n  font-size: 13px !important;\n  scrollbar-color: var(--muted) var(--surface);\n  scrollbar-width: thin;\n}\n\n.sts-popup *::-webkit-scrollbar {\n  width: 10px;\n  height: 10px;\n}\n\n.sts-popup *::-webkit-scrollbar-track {\n  border-left: 1px solid var(--border-muted);\n  background: var(--surface);\n}\n\n.sts-popup *::-webkit-scrollbar-thumb {\n  border: 2px solid var(--surface);\n  background: var(--muted);\n}\n\n.sts-popup *::-webkit-scrollbar-thumb:hover {\n  background: var(--primary);\n}\n\n.sts-popup *::-webkit-scrollbar-corner {\n  background: var(--surface);\n}\n\n.sts-compose textarea::-webkit-resizer {\n  background: var(--surface);\n}\n\n.sts-tooltip {\n  position: fixed;\n  inset: 0;\n  z-index: 2147483647;\n  display: none;\n  opacity: 0;\n  visibility: hidden;\n  pointer-events: none;\n  user-select: none;\n  transition:\n    opacity 120ms var(--ease),\n    visibility 120ms var(--ease);\n}\n\n.sts-tooltip.sts-visible {\n  opacity: 1;\n  visibility: visible;\n}\n\n.sts-tooltip-stack {\n  position: absolute;\n  display: inline-flex;\n  gap: 0;\n  border: 2px solid var(--border);\n  background: var(--surface);\n  transform: translateY(-8px);\n  transition:\n    transform 140ms var(--ease);\n  will-change: transform;\n}\n\n.sts-tooltip.sts-visible .sts-tooltip-stack {\n  transform: translateY(0);\n}\n\n.sts-tooltip-btn {\n  min-width: 82px;\n  height: 30px;\n  padding: 0 9px;\n  border: 0;\n  border-right: 1px solid var(--border-muted);\n  border-radius: 0;\n  background: var(--surface);\n  box-shadow: inset 0 0 0 0 var(--border-muted);\n  color: var(--text);\n  cursor: pointer;\n  font-weight: 800 !important;\n  outline: none;\n  pointer-events: auto;\n  transition:\n    box-shadow 100ms var(--ease);\n  will-change: box-shadow;\n}\n\n.sts-tooltip-btn:last-child {\n  border-right: 0;\n}\n\n.sts-tooltip-btn:hover {\n  box-shadow: inset 0 0 0 2px var(--border);\n}\n\n.sts-tooltip-btn:active {\n  color: var(--background);\n  box-shadow: inset 0 0 0 20px var(--border);\n}\n\n.sts-popup {\n  --popup-max-height: calc(100vh - 32px);\n  position: fixed;\n  top: 16px;\n  right: 16px;\n  z-index: 2147483647;\n  width: min(380px, 92vw);\n  max-height: var(--popup-max-height);\n  display: none;\n  opacity: 0;\n  visibility: hidden;\n  color: var(--text);\n  transition:\n    opacity 140ms var(--ease),\n    visibility 140ms var(--ease);\n}\n\n.sts-popup.sts-visible {\n  opacity: 1;\n  visibility: visible;\n}\n\n.sts-popup-inner {\n  display: flex;\n  flex-direction: column;\n  width: 100%;\n  max-height: var(--popup-max-height);\n  overflow: hidden;\n  border: 2px solid var(--border);\n  background: var(--surface);\n  transform: translateY(-6px);\n  transition: transform 140ms var(--ease);\n}\n\n.sts-popup.sts-visible .sts-popup-inner {\n  transform: translateY(0);\n}\n\n.sts-popup-header {\n  display: flex;\n  flex: 0 0 auto;\n  align-items: center;\n  justify-content: space-between;\n  gap: 8px;\n  min-height: 42px;\n  padding: 6px 8px;\n  border-bottom: 2px solid var(--border);\n  background: var(--surface);\n}\n\n.sts-popup-header .title {\n  display: flex;\n  align-items: center;\n  min-width: 0;\n  flex: 1 1 auto;\n  color: var(--text);\n  font-weight: 800 !important;\n}\n\n.sts-back {\n  display: inline-flex;\n  align-items: center;\n  gap: 5px;\n  min-width: 0;\n  padding: 0;\n  border: 0;\n  background: transparent;\n  color: inherit;\n  cursor: pointer;\n  font: inherit;\n  font-weight: 800 !important;\n  overflow: hidden;\n  text-overflow: ellipsis;\n  white-space: nowrap;\n}\n\n.sts-popup-header .actions {\n  display: flex;\n  flex: 0 0 auto;\n  gap: 6px;\n}\n\n.sts-btn,\n.sts-mode,\n.sts-select,\n.sts-compose textarea {\n  font: inherit;\n}\n\n.sts-btn,\n.sts-mode {\n  display: inline-flex;\n  align-items: center;\n  justify-content: center;\n  gap: 5px;\n  min-height: 30px;\n  padding: 0 9px;\n  border: 2px solid var(--border);\n  border-radius: 0;\n  background: var(--surface);\n  box-shadow: inset 0 0 0 0 var(--border);\n  color: var(--text);\n  cursor: pointer;\n  font-weight: 800 !important;\n  outline: none;\n  transition:\n    box-shadow 100ms var(--ease),\n    color 100ms var(--ease),\n    opacity 100ms var(--ease);\n  will-change: box-shadow, color, opacity;\n}\n\n.sts-copy {\n  min-width: 90px;\n}\n\n.sts-btn:not([disabled]):hover,\n.sts-mode:hover {\n  box-shadow: inset 0 0 0 2px var(--border);\n}\n\n.sts-btn:focus-visible,\n.sts-mode:focus-visible,\n.sts-select:focus-visible,\n.sts-compose textarea:focus-visible {\n  animation: sts-focus-throb 600ms var(--ease) infinite alternate;\n  box-shadow: 0 0 0 0 var(--border);\n  outline: 0;\n}\n\n.sts-btn:not([disabled]):active,\n.sts-mode:active {\n  color: var(--background);\n  box-shadow: inset 0 0 0 20px var(--border);\n}\n\n.sts-icon {\n  flex: 0 0 auto;\n  width: 16px;\n  height: 16px;\n}\n\n.sts-btn[disabled] {\n  cursor: not-allowed;\n  opacity: 0.66;\n}\n\n.sts-popup-header .sts-btn[disabled] {\n  display: none;\n}\n\n.sts-btn--tinted {\n  background: var(--primary);\n  box-shadow: inset 0 0 0 0 var(--surface);\n  color: var(--background);\n}\n\n.sts-btn--tinted:not([disabled]):hover {\n  box-shadow: inset 0 0 0 2px var(--surface);\n}\n\n.sts-btn--tinted:not([disabled]):active {\n  color: var(--primary);\n  box-shadow: inset 0 0 0 20px var(--surface);\n}\n\n.sts-btn--icon {\n  width: 30px;\n  min-width: 30px;\n  padding: 0;\n}\n\n.sts-content {\n  flex: 0 1 auto;\n  min-height: 0;\n  padding: 8px;\n  overflow-y: auto;\n  overflow-x: hidden;\n  max-height: calc(var(--popup-max-height) - 118px);\n  background: var(--surface);\n  color: var(--text);\n  animation: sts-enter 120ms var(--ease);\n}\n\n.sts-content:empty {\n  display: none;\n}\n\n.sts-content,\n.sts-content * {\n  color: var(--text);\n  line-height: 1.45;\n}\n\n.sts-mode-grid {\n  display: grid;\n  grid-template-columns: repeat(2, minmax(0, 1fr));\n  border: 2px solid var(--border);\n  border-bottom: 0;\n}\n\n.sts-mode {\n  height: 42px;\n  border: 0;\n  border-right: 2px solid var(--border);\n  border-bottom: 2px solid var(--border);\n  text-align: left;\n}\n\n.sts-mode:nth-child(2n) {\n  border-right: 0;\n}\n\n.sts-compose {\n  flex: 0 0 auto;\n  padding: 8px;\n  background: var(--surface);\n  animation: sts-enter 120ms var(--ease);\n}\n\n.sts-compose:empty {\n  display: none;\n}\n\n.sts-mode-form {\n  display: grid;\n  gap: 8px;\n}\n\n.sts-ask-grid {\n  display: grid;\n  gap: 8px;\n}\n\n.sts-mode-form:has([data-run="summary-page"]) {\n  grid-template-columns: 1fr 1fr;\n}\n\n.sts-select,\n.sts-compose textarea {\n  width: 100%;\n  border: 2px solid var(--border);\n  border-radius: 0;\n  background: var(--surface);\n  color: var(--text);\n  outline: none;\n  will-change: box-shadow;\n}\n\n.sts-select {\n  height: 30px;\n  padding: 0 8px;\n  font-weight: 800 !important;\n}\n\n.sts-compose textarea {\n  min-height: 76px;\n  padding: 7px 8px;\n  resize: vertical;\n  line-height: 1.4;\n}\n\n.sts-ask-grid textarea {\n  min-height: 35px;\n}\n\n.sts-ask-actions {\n  display: flex;\n  gap: 0;\n  transition: gap 140ms var(--ease);\n}\n\n.sts-ask-actions [data-run="ask"] {\n  flex: 1 1 auto;\n  min-width: 0;\n}\n\n.sts-ask-actions .sts-new-session {\n  width: 0;\n  min-width: 0;\n  padding: 0;\n  border-width: 0;\n  opacity: 0;\n  overflow: hidden;\n  pointer-events: none;\n  transition:\n    width 140ms var(--ease),\n    min-width 140ms var(--ease),\n    padding 140ms var(--ease),\n    border-width 140ms var(--ease),\n    box-shadow 100ms var(--ease),\n    color 100ms var(--ease),\n    opacity 100ms var(--ease);\n}\n\n.sts-ask-actions.sts-has-session .sts-new-session {\n  width: 30px;\n  min-width: 30px;\n  padding: 0;\n  border-width: 2px;\n  opacity: 1;\n  pointer-events: auto;\n}\n\n.sts-ask-actions.sts-has-session {\n  gap: 8px;\n}\n\n.sts-turn-label {\n  display: block;\n  margin-bottom: 8px;\n  color: var(--muted);\n  font-size: 11px !important;\n  font-weight: 800 !important;\n}\n\n.sts-chat {\n  display: grid;\n  gap: 8px;\n}\n\n.sts-message {\n  display: grid;\n  gap: 4px;\n  padding-bottom: 8px;\n  border-bottom: 1px solid var(--border-muted);\n}\n\n.sts-message:last-child {\n  padding-bottom: 0;\n  border-bottom: 0;\n}\n\n.sts-message-role {\n  color: var(--muted);\n  font-size: 11px !important;\n  font-weight: 800 !important;\n}\n\n.sts-message-text {\n  white-space: pre-wrap;\n  overflow-wrap: anywhere;\n}\n\n.sts-message[data-streaming="true"] .sts-message-text:empty::before {\n  color: var(--muted);\n  content: "Thinking...";\n}\n\n.sts-message--user .sts-message-text {\n  font-weight: 800 !important;\n}\n\n.sts-empty,\n.sts-help {\n  color: var(--muted);\n  font-size: 12px !important;\n  line-height: 1.35;\n}\n\n.sts-help {\n  margin: 8px 0 0;\n  padding: 8px;\n  border: 2px solid var(--border);\n  background: var(--surface-soft);\n  white-space: pre-wrap;\n}\n\n.sts-api-grid {\n  display: grid;\n  border: 2px solid var(--border);\n  border-bottom: 0;\n}\n\n.sts-api-row {\n  display: flex;\n  justify-content: space-between;\n  gap: 12px;\n  min-height: 29px;\n  padding: 5px 8px;\n  border-bottom: 1px solid var(--border-muted);\n}\n\n.sts-api-row strong,\n.sts-api-row span {\n  font-size: 12px !important;\n}\n\n.sts-api-row span {\n  color: var(--muted);\n  text-align: right;\n}\n\n.sts-stream-shell {\n  min-height: 1.45em;\n}\n\n.sts-stream-status {\n  display: none;\n  color: var(--muted);\n  font-size: 12px !important;\n  font-weight: 800 !important;\n}\n\n.sts-stream-status:not(:empty) {\n  display: block;\n  animation: sts-enter 120ms var(--ease);\n}\n\n.sts-error {\n  padding: 8px;\n  border: 2px solid var(--danger);\n  color: var(--danger);\n  font-weight: 800 !important;\n}\n\n.sts-content-md,\n.sts-stream-text {\n  color: var(--text);\n  display: block;\n  font-size: 13px !important;\n  font-weight: 400 !important;\n  height: auto !important;\n  line-height: 1.45;\n  margin: 0 !important;\n  max-height: none !important;\n  min-height: 0 !important;\n  overflow-x: auto !important;\n  overflow-y: visible !important;\n  overscroll-behavior-x: contain;\n  padding: 0 !important;\n}\n\n.sts-content-md > *:first-child {\n  margin-top: 0 !important;\n}\n\n.sts-content-md > *:last-child {\n  margin-bottom: 0 !important;\n}\n\n.sts-content-md p,\n.sts-content-md ul,\n.sts-content-md ol,\n.sts-content-md blockquote,\n.sts-content-md pre {\n  margin: 0 0 8px !important;\n}\n\n.sts-content-md h1,\n.sts-content-md h2,\n.sts-content-md h3 {\n  margin: 10px 0 6px !important;\n  color: var(--text);\n  font-size: 13px !important;\n  font-weight: 800 !important;\n  line-height: 1.35;\n}\n\n.sts-content-md ul,\n.sts-content-md ol {\n  padding-left: 18px !important;\n}\n\n.sts-content-md li {\n  margin: 2px 0 !important;\n  padding-left: 2px !important;\n}\n\n.sts-content-md blockquote {\n  padding-left: 8px !important;\n  border-left: 2px solid var(--border-muted);\n  color: var(--muted);\n}\n\n.sts-content-md pre {\n  display: block;\n  width: max-content;\n  min-width: 100%;\n  max-width: none;\n  padding: 8px !important;\n  overflow: visible !important;\n  border: 2px solid var(--border);\n  background: var(--surface-soft);\n  white-space: pre;\n}\n\n.sts-content-md code {\n  padding: 0 3px !important;\n  border: 1px solid var(--border-muted);\n  background: var(--surface-soft);\n  font: inherit;\n}\n\n.sts-content-md pre code {\n  display: block;\n  padding: 0 !important;\n  border: 0;\n  background: transparent;\n  white-space: pre;\n}\n\n.sts-content-md a {\n  color: var(--text);\n  font-weight: 800 !important;\n  text-decoration: underline;\n  text-decoration-thickness: 1px;\n  text-underline-offset: 2px;\n}\n\n.sts-stream-text {\n  white-space: pre-wrap;\n}\n\n@keyframes sts-enter {\n  from {\n    opacity: 0;\n    transform: translateY(3px);\n  }\n  to {\n    opacity: 1;\n    transform: translateY(0);\n  }\n}\n\n@keyframes sts-focus-throb {\n  from {\n    box-shadow: 0 0 0 0 var(--border);\n  }\n  to {\n    box-shadow: 0 0 0 2px var(--border);\n  }\n}\n\n@media (prefers-reduced-motion: reduce) {\n  .sts-tooltip,\n  .sts-tooltip *,\n  .sts-popup,\n  .sts-popup * {\n    transition-duration: 1ms !important;\n    animation: none !important;\n  }\n}\n';

  // src/icons/back.svg
  var back_default = '<svg\n  xmlns="http://www.w3.org/2000/svg"\n  width="1000"\n  height="1000"\n  viewBox="0 0 8 8"\n  fill="none"\n>\n  <!--<rect width="8" height="8" fill="#999" fill-opacity="1" />-->\n  <path\n    d="\n    M 5 7\n    L 2 4\n    L 5 1\n  "\n    stroke="currentColor"\n    stroke-width="1"\n    stroke-linecap="square"\n  />\n\n  <path\n    d="\n    M 2 4\n    L 7 4\n  "\n    stroke="currentColor"\n    stroke-width="1"\n  />\n</svg>\n';

  // src/icons/copy.svg
  var copy_default = '<svg\n  xmlns="http://www.w3.org/2000/svg"\n  width="1000"\n  height="1000"\n  viewBox="0 0 8 8"\n  fill="none"\n>\n  <!--<rect width="8" height="8" fill="red" fill-opacity="1" />-->\n  <path\n    d="\n    M 1 6\n    L 1 1\n    L 6 1\n    M 3 7\n    L 3 3\n    L 7 3\n    L 7 7\n    L 3 7\n    Z\n    "\n    stroke="currentColor"\n    stroke-width="1"\n    stroke-linecap="square"\n  />\n</svg>\n';

  // src/icons/database.svg
  var database_default = '<svg\n  xmlns="http://www.w3.org/2000/svg"\n  width="1000"\n  height="1000"\n  viewBox="0 0 8 8"\n  fill="none"\n>\n  <!--<rect width="8" height="8" fill="#999" fill-opacity="1" />-->\n  <path\n    d="\n    M 1 7\n    L 1 1\n    L 7 1\n    L 7 7\n    L 1 7\n    Z\n    M 1 3\n    L 7 3\n    M 1 5\n    L 7 5\n    "\n    stroke="currentColor"\n    stroke-width="1"\n    stroke-linecap="square"\n  />\n</svg>\n';

  // src/icons/external-link.svg
  var external_link_default = '<svg\n  xmlns="http://www.w3.org/2000/svg"\n  width="1000"\n  height="1000"\n  viewBox="0 0 8 8"\n  fill="none"\n>\n  <!--<rect width="8" height="8" fill="#999" fill-opacity="1" />-->\n  <path\n    d="\n    M 3 2\n    L 1 2\n    L 1 7\n    L 6 7\n    L 6 5\n    "\n    stroke="currentColor"\n    stroke-width="1"\n    stroke-linejoin="arcs"\n  />\n  <path\n    d="\n    M 4 1\n    L 7 1\n    L 7 4\n    "\n    stroke="currentColor"\n    stroke-width="1"\n    stroke-linejoin="arcs"\n  />\n  <path\n    d="\n    M 7 1\n    L 4 4\n    "\n    stroke="currentColor"\n    stroke-width="1"\n  />\n</svg>\n';

  // src/icons/new-session.svg
  var new_session_default = '<svg\n  xmlns="http://www.w3.org/2000/svg"\n  width="1000"\n  height="1000"\n  viewBox="0 0 8 8"\n  fill="none"\n>\n  <!-- <rect width="8" height="8" fill="#999" fill-opacity="1" /> -->\n  <path\n    d="\n    M 4 2\n    l 0 4\n    M 2 4\n    l 4 0\n    "\n    stroke="currentColor"\n    stroke-width="1"\n    stroke-linecap="square"\n  />\n</svg>\n';

  // src/icons/ok.svg
  var ok_default = '<svg\n  xmlns="http://www.w3.org/2000/svg"\n  width="1000"\n  height="1000"\n  viewBox="0 0 8 8"\n  fill="none"\n>\n  <!-- <rect width="8" height="8" fill="#999" fill-opacity="1" /> -->\n  <path\n    d="\n    M 1.5 4\n    L 3 5.5\n    L 6.5 2\n    "\n    stroke="currentColor"\n    stroke-width="1.2"\n    stroke-linecap="square"\n    stroke-linejoin="miter"\n  />\n</svg>\n';

  // src/icons/refresh.svg
  var refresh_default = '<svg\n  xmlns="http://www.w3.org/2000/svg"\n  width="1000"\n  height="1000"\n  viewBox="0 0 8 8"\n  fill="none"\n>\n  <!--<rect width="8" height="8" fill="#f0f0f0" fill-opacity="1" />-->\n  <path\n    d="\n    M 7 4\n    L 7 2\n    L 1 2\n    L 1 6\n    L 5 6\n    M 4 5\n    L 6 6\n    L 4 7\n    z\n\n    "\n    stroke="currentColor"\n    stroke-width="1"\n  />\n</svg>\n';

  // src/icons/save.svg
  var save_default = '<svg\n  xmlns="http://www.w3.org/2000/svg"\n  width="1000"\n  height="1000"\n  viewBox="0 0 8 8"\n  fill="none"\n>\n  <!--<rect width="8" height="8" fill="#999" fill-opacity="1" />-->\n  <path\n    d="\n    M 1 1\n    L 5 1\n    L 7 3\n    L 7 7\n    L 1 7\n    z\n    "\n    stroke="currentColor"\n    stroke-width="1"\n    stroke-linecap="square"\n  />\n  <rect\n    width="3"\n    height="3"\n    fill="currentColor"\n    fill-opacity="1"\n    x="2.5"\n    y="4"\n  />\n</svg>\n';

  // src/icons/start.svg
  var start_default = '<svg\n  xmlns="http://www.w3.org/2000/svg"\n  width="1000"\n  height="1000"\n  viewBox="0 0 8 8"\n  fill="currentColor"\n>\n  <!--<rect width="8" height="8" fill="#999" fill-opacity="1" />-->\n  <path\n    d="\n    M 2 2\n    L 5 4\n    L 2 6\n    z\n    "\n    stroke="currentColor"\n    stroke-width="1"\n  />\n</svg>\n';

  // src/icons/stop.svg
  var stop_default = '<svg\n  xmlns="http://www.w3.org/2000/svg"\n  width="1000"\n  height="1000"\n  viewBox="0 0 8 8"\n  fill="none"\n>\n  <!--<rect width="8" height="8" fill="#999" fill-opacity="1" />-->\n  <rect\n    x="2"\n    y="2"\n    width="4"\n    height="4"\n    stroke="currentColor"\n    stroke-width="1"\n    stroke-linecap="square"\n  />\n</svg>\n';

  // src/icons/x.svg
  var x_default = '<svg\n  xmlns="http://www.w3.org/2000/svg"\n  width="1000"\n  height="1000"\n  viewBox="0 0 8 8"\n  fill="currentColor"\n>\n  <!--<rect width="8" height="8" fill="#999" fill-opacity="1" />-->\n  <path\n    d="\n    M 2 2\n    L 6 6\n    M 6 2\n    L 2 6\n    "\n    stroke="currentColor"\n    stroke-width="1"\n    stroke-linecap="square"\n  />\n</svg>\n';

  // src/lib/filled-icons.js
  var ICON_SVGS = {
    back: back_default,
    copy: copy_default,
    database: database_default,
    "external-link": external_link_default,
    "new-session": new_session_default,
    ok: ok_default,
    refresh: refresh_default,
    save: save_default,
    start: start_default,
    stop: stop_default,
    x: x_default
  };
  var parser = new DOMParser();
  function createFilledIcon(name) {
    const source = ICON_SVGS[name];
    if (!source) return null;
    const doc = parser.parseFromString(source, "image/svg+xml");
    const svg = doc.documentElement;
    if (svg.nodeName.toLowerCase() !== "svg") return null;
    const icon = document.importNode(svg, true);
    icon.setAttribute("aria-hidden", "true");
    icon.setAttribute("focusable", "false");
    return icon;
  }

  // src/lib/markdown.js
  var SAFE_LINK_PROTOCOLS = /* @__PURE__ */ new Set(["http:", "https:", "mailto:"]);
  function renderPlainText(value) {
    return escapeHtml(value).replace(/\n/g, "<br>");
  }
  function renderMarkdown(value) {
    const lines = String(value || "").replace(/\r\n?/g, "\n").split("\n");
    const blocks = [];
    let index = 0;
    while (index < lines.length) {
      const line = lines[index];
      if (!line.trim()) {
        index += 1;
        continue;
      }
      if (/^```/.test(line.trim())) {
        const fence = [];
        index += 1;
        while (index < lines.length && !/^```/.test(lines[index].trim())) {
          fence.push(lines[index]);
          index += 1;
        }
        if (index < lines.length) index += 1;
        blocks.push(`<pre><code>${escapeHtml(fence.join("\n"))}</code></pre>`);
        continue;
      }
      const heading = /^(#{1,3})\s+(.+)$/.exec(line);
      if (heading) {
        const level = heading[1].length;
        blocks.push(`<h${level}>${renderInline(heading[2])}</h${level}>`);
        index += 1;
        continue;
      }
      if (/^\s*>\s?/.test(line)) {
        const quote = [];
        while (index < lines.length && /^\s*>\s?/.test(lines[index])) {
          quote.push(lines[index].replace(/^\s*>\s?/, ""));
          index += 1;
        }
        blocks.push(`<blockquote>${renderParagraphs(quote)}</blockquote>`);
        continue;
      }
      if (/^\s*[-*]\s+/.test(line)) {
        const items = [];
        while (index < lines.length && /^\s*[-*]\s+/.test(lines[index])) {
          items.push(lines[index].replace(/^\s*[-*]\s+/, ""));
          index += 1;
        }
        blocks.push(renderList("ul", items));
        continue;
      }
      if (/^\s*\d+[.)]\s+/.test(line)) {
        const items = [];
        while (index < lines.length && /^\s*\d+[.)]\s+/.test(lines[index])) {
          items.push(lines[index].replace(/^\s*\d+[.)]\s+/, ""));
          index += 1;
        }
        blocks.push(renderList("ol", items));
        continue;
      }
      const paragraph = [line.trim()];
      index += 1;
      while (index < lines.length && lines[index].trim() && !isBlockStart(lines[index])) {
        paragraph.push(lines[index].trim());
        index += 1;
      }
      blocks.push(`<p>${renderInline(paragraph.join(" "))}</p>`);
    }
    return blocks.join("");
  }
  function renderParagraphs(lines) {
    return lines.join("\n").split(/\n{2,}/).map((paragraph) => paragraph.trim()).filter(Boolean).map((paragraph) => `<p>${renderInline(paragraph.replace(/\n/g, " "))}</p>`).join("");
  }
  function renderList(tag, items) {
    return `<${tag}>${items.map((item) => `<li>${renderInline(item)}</li>`).join("")}</${tag}>`;
  }
  function renderInline(value) {
    const tokens = [];
    const tokenPrefix = "\0MD";
    const tokenSuffix = "\0";
    let text = String(value || "").replace(/`([^`]+)`/g, (_, code) => {
      const token = `${tokenPrefix}${tokens.length}${tokenSuffix}`;
      tokens.push(`<code>${escapeHtml(code)}</code>`);
      return token;
    });
    text = text.replace(
      /\[([^\]]+)\]\(((?:[^()\s]|\([^)]*\))+)\)/g,
      (_, label, href) => {
        const safeHref = normalizeSafeHref(href);
        if (!safeHref) return label;
        const token = `${tokenPrefix}${tokens.length}${tokenSuffix}`;
        tokens.push(
          `<a href="${escapeHtml(safeHref)}" target="_blank" rel="noreferrer">${renderInline(label)}</a>`
        );
        return token;
      }
    );
    text = escapeHtml(text).replace(/\*\*([^*]+)\*\*/g, "<strong>$1</strong>").replace(/(^|[^*])\*([^*\n]+)\*/g, "$1<em>$2</em>");
    tokens.forEach((html, tokenIndex) => {
      text = text.replaceAll(
        `${tokenPrefix}${tokenIndex}${tokenSuffix}`,
        html
      );
    });
    return text;
  }
  function isBlockStart(line) {
    return /^```/.test(line.trim()) || /^(#{1,3})\s+/.test(line) || /^\s*>\s?/.test(line) || /^\s*[-*]\s+/.test(line) || /^\s*\d+[.)]\s+/.test(line);
  }
  function normalizeSafeHref(href) {
    try {
      const url = new URL(String(href || ""), location.href);
      if (!SAFE_LINK_PROTOCOLS.has(url.protocol)) return "";
      return url.href;
    } catch (_) {
      return "";
    }
  }
  function escapeHtml(value) {
    return String(value || "").replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;").replace(/'/g, "&#039;");
  }

  // src/content.js
  (() => {
    const CONFIG_KEY = "sts_config";
    const PERFORMANCE_KEY = "sts_performance";
    const DEFAULT_MIN_WORDS = 12;
    const DEFAULT_CONFIG = {
      minWords: DEFAULT_MIN_WORDS,
      ask: {
        style: "concise",
        format: "markdown"
      },
      summarize: {
        page: {
          type: "key-points",
          format: "markdown",
          length: "medium",
          instructions: "Ignore navigation, footer, cookie notices, advertisements, and unrelated links."
        },
        selection: {
          type: "key-points",
          format: "markdown",
          length: "short",
          instructions: "Focus on the selected text. Keep the result compact."
        }
      }
    };
    const ALLOWED = {
      askStyle: ["concise", "balanced", "detailed"],
      format: ["markdown", "plain-text"],
      summaryType: ["key-points", "tldr", "teaser", "headline"],
      summaryLength: ["short", "medium", "long"]
    };
    const ICONS = {
      back: "back",
      copy: "copy",
      close: "x",
      newSession: "new-session",
      stop: "stop"
    };
    const MAX_CONTEXT_CHARS = 18e3;
    const MAX_SELECTION_CHARS = 12e3;
    const MAX_CHAT_HISTORY_CHARS = 8e3;
    const API_NAMES = ["LanguageModel", "Summarizer"];
    const TEXT_ENTRY_EVENT_TYPES = [
      "beforeinput",
      "compositionend",
      "compositionstart",
      "compositionupdate",
      "cut",
      "input",
      "keydown",
      "keypress",
      "keyup",
      "paste"
    ];
    const API_AVAILABILITY_OPTIONS = {
      LanguageModel: {
        expectedInputs: [{ type: "text", languages: ["en", "es", "ja"] }],
        expectedOutputs: [{ type: "text", languages: ["en", "es", "ja"] }]
      }
    };
    const LANGUAGE_MODEL_OPTION_FALLBACKS = [
      API_AVAILABILITY_OPTIONS.LanguageModel,
      {
        expectedInputs: [{ type: "text", languages: ["en"] }],
        expectedOutputs: [{ type: "text", languages: ["en"] }]
      },
      {}
    ];
    const state = {
      tooltipEl: null,
      panelEl: null,
      currentMode: "home",
      selectionText: "",
      pageContext: null,
      minWords: DEFAULT_MIN_WORDS,
      config: DEFAULT_CONFIG,
      activeController: null,
      languageSession: null,
      outputEl: null,
      streamBuffer: "",
      streamRenderFrame: null,
      lastAnswer: "",
      chatMessages: [],
      chatContext: null,
      isRunning: false,
      isSelectingWithPointer: false,
      focusedTextEntryEl: null,
      performanceMetrics: {
        avgCharsPerSecond: 18,
        runCount: 0
      },
      lastMouseX: 0,
      lastMouseY: 0
    };
    let configReady = null;
    function loadConfig() {
      if (!chrome.storage?.sync) {
        state.config = normalizeConfig();
        state.minWords = state.config.minWords;
        configReady = Promise.resolve(state.config);
        return configReady;
      }
      configReady = new Promise((resolve) => {
        chrome.storage.sync.get([CONFIG_KEY, PERFORMANCE_KEY], (res) => {
          state.config = normalizeConfig(res?.[CONFIG_KEY]);
          state.minWords = state.config.minWords;
          const perf = res?.[PERFORMANCE_KEY];
          if (perf && typeof perf.avgCharsPerSecond === "number" && typeof perf.runCount === "number") {
            state.performanceMetrics = {
              avgCharsPerSecond: Math.max(1, perf.avgCharsPerSecond),
              runCount: Math.max(0, perf.runCount)
            };
          }
          resolve(state.config);
        });
      });
      return configReady;
    }
    async function ensureConfig() {
      if (!configReady) loadConfig();
      await configReady;
      return state.config;
    }
    chrome.storage?.onChanged?.addListener((changes, areaName) => {
      if (areaName !== "sync" || !changes[CONFIG_KEY]) return;
      state.config = normalizeConfig(changes[CONFIG_KEY].newValue);
      state.minWords = state.config.minWords;
    });
    function pickAllowed(value, allowed, fallback) {
      return allowed.includes(value) ? value : fallback;
    }
    function normalizeText(value, fallback = "") {
      const text = String(value ?? "").trim();
      return (text || fallback).slice(0, 500);
    }
    function normalizeConfig(config = {}) {
      return {
        minWords: normalizeMinWords(config.minWords ?? DEFAULT_MIN_WORDS),
        ask: {
          style: pickAllowed(
            config.ask?.style,
            ALLOWED.askStyle,
            DEFAULT_CONFIG.ask.style
          ),
          format: pickAllowed(
            config.ask?.format,
            ALLOWED.format,
            DEFAULT_CONFIG.ask.format
          )
        },
        summarize: {
          page: normalizeSummaryConfig(
            config.summarize?.page,
            DEFAULT_CONFIG.summarize.page
          ),
          selection: normalizeSummaryConfig(
            config.summarize?.selection,
            DEFAULT_CONFIG.summarize.selection
          )
        }
      };
    }
    function normalizeMinWords(value) {
      const num = Number(value);
      return Math.max(1, Number.isFinite(num) ? num : DEFAULT_MIN_WORDS);
    }
    function normalizeSummaryConfig(config = {}, defaults) {
      return {
        type: pickAllowed(config.type, ALLOWED.summaryType, defaults.type),
        format: pickAllowed(config.format, ALLOWED.format, defaults.format),
        length: pickAllowed(
          config.length,
          ALLOWED.summaryLength,
          defaults.length
        ),
        instructions: normalizeText(config.instructions, defaults.instructions)
      };
    }
    function savePerformanceMetrics(cps) {
      const { avgCharsPerSecond: avg, runCount } = state.performanceMetrics;
      const newRunCount = runCount + 1;
      const newAvg = avg + (cps - avg) / newRunCount;
      state.performanceMetrics = {
        avgCharsPerSecond: newAvg,
        runCount: newRunCount
      };
      chrome.storage?.sync?.set({ [PERFORMANCE_KEY]: state.performanceMetrics });
    }
    const countWords = (text) => (String(text).trim().match(/\b[\p{L}\p{N}'-]+\b/gu) || []).length;
    const cleanText = (text) => String(text || "").replace(/\u00a0/g, " ").replace(/[ \t]+/g, " ").replace(/\n{3,}/g, "\n\n").trim();
    function getSelectionText() {
      const sel = window.getSelection();
      return !sel || sel.rangeCount === 0 ? "" : cleanText(sel.toString());
    }
    function truncateText(text, maxChars) {
      const value = cleanText(text);
      if (value.length <= maxChars) return value;
      return `${value.slice(0, maxChars).trim()}

[Context truncated at ${maxChars} characters.]`;
    }
    function ensureTooltip() {
      if (state.tooltipEl) return state.tooltipEl;
      const el = document.createElement("div");
      el.className = "sts-tooltip";
      el.innerHTML = `
      <div class="sts-tooltip-stack">
        <button class="sts-tooltip-btn sts-tooltip-summary" type="button">Summarize</button>
      </div>
    `;
      el.addEventListener("transitionend", (e) => {
        if (e.target === el && !el.classList.contains("sts-visible")) {
          el.style.display = "none";
        }
      });
      el.querySelector(".sts-tooltip-summary")?.addEventListener(
        "mousedown",
        consumeMouse
      );
      el.querySelector(".sts-tooltip-summary")?.addEventListener("click", () => {
        window.getSelection()?.removeAllRanges();
        runQuickAction("summarize-selection");
      });
      createShadowUiRoot("tooltip").appendChild(el);
      return state.tooltipEl = el;
    }
    function createShadowUiRoot(name) {
      const host = document.createElement("div");
      host.dataset.localAiRoot = name;
      setIsolatedHostStyle(host);
      const root = host.attachShadow({ mode: "closed" });
      const style = document.createElement("style");
      style.textContent = content_default;
      root.appendChild(style);
      (document.body || document.documentElement).appendChild(host);
      return root;
    }
    function setIsolatedHostStyle(host) {
      const importantStyles = {
        all: "initial",
        contain: "style",
        display: "block",
        height: "0",
        overflow: "visible",
        position: "static",
        width: "0"
      };
      Object.entries(importantStyles).forEach(([property, value]) => {
        host.style.setProperty(property, value, "important");
      });
    }
    function consumeMouse(event) {
      event.preventDefault();
      event.stopPropagation();
    }
    function isLocalAiEvent(event) {
      return event.composedPath?.().some((node) => node?.dataset?.localAiRoot);
    }
    function stopLocalAiEvent(event) {
      if (!isLocalAiEvent(event)) return;
      handleContainedTextEntryShortcut(event);
      event.stopPropagation();
      event.stopImmediatePropagation?.();
    }
    function handleContainedTextEntryShortcut(event) {
      if (event.type !== "keydown" || event.key !== "Enter" || event.shiftKey || state.focusedTextEntryEl?.id !== "sts-question") {
        return;
      }
      event.preventDefault();
      state.focusedTextEntryEl.form?.requestSubmit();
    }
    function installTextEntryFirewall() {
      TEXT_ENTRY_EVENT_TYPES.forEach((eventType) => {
        window.addEventListener(eventType, stopLocalAiEvent, true);
      });
    }
    function trackTextEntryElement(input) {
      input?.addEventListener("focus", () => {
        state.focusedTextEntryEl = input;
      });
      input?.addEventListener("blur", () => {
        if (state.focusedTextEntryEl === input) state.focusedTextEntryEl = null;
      });
    }
    function showTooltipAt(rect) {
      const el = ensureTooltip();
      const stack = el.querySelector(".sts-tooltip-stack");
      if (!stack) return;
      el.style.display = "block";
      const tooltipRect = stack.getBoundingClientRect();
      const margin = 12;
      const width = tooltipRect.width || 156;
      const height = tooltipRect.height || 36;
      let top = state.lastMouseY + margin;
      let left = state.lastMouseX + margin;
      if (left + width > window.innerWidth - margin) {
        left = state.lastMouseX - width - margin;
      }
      if (top + height > window.innerHeight - margin) {
        top = state.lastMouseY - height - margin;
      }
      stack.style.top = `${Math.max(margin, top)}px`;
      stack.style.left = `${Math.max(margin, left)}px`;
      setTimeout(() => el.classList.add("sts-visible"), 10);
    }
    const hideTooltip = () => state.tooltipEl?.classList.remove("sts-visible");
    function ensurePanel() {
      if (state.panelEl) return state.panelEl;
      const el = document.createElement("section");
      el.className = "sts-popup sts-assistant";
      el.setAttribute("aria-label", "Local AI");
      el.innerHTML = `
      <div class="sts-popup-inner">
        <div class="sts-popup-header">
          <div class="title"><button class="sts-back" type="button" title="Modes">Local AI</button></div>
          <div class="actions">
            <button class="sts-btn sts-btn--ghost sts-copy" type="button">Copy</button>
            <button class="sts-btn sts-btn--ghost sts-stop" type="button">Stop</button>
            <button class="sts-btn sts-btn--ghost sts-btn--icon sts-close" type="button" aria-label="Close assistant" title="Close assistant"></button>
          </div>
        </div>
        <div class="sts-content" id="sts-content">
          <div class="sts-empty"></div>
        </div>
        <div class="sts-compose" id="sts-compose"></div>
      </div>
    `;
      el.addEventListener("transitionend", (e) => {
        if (e.target === el && !el.classList.contains("sts-visible")) {
          el.style.display = "none";
        }
      });
      el.querySelector(".sts-close")?.addEventListener("click", hidePanel);
      el.querySelector(".sts-back")?.addEventListener(
        "click",
        () => renderMode("home")
      );
      el.querySelector(".sts-copy")?.addEventListener("click", copyAnswer);
      el.querySelector(".sts-stop")?.addEventListener("click", stopCurrentRun);
      createShadowUiRoot("panel").appendChild(el);
      state.panelEl = el;
      decoratePanelIcons();
      renderMode("home");
      return state.panelEl;
    }
    function decoratePanelIcons() {
      setIconButton(state.panelEl?.querySelector(".sts-copy"), "copy", "Copy");
      setIconButton(state.panelEl?.querySelector(".sts-stop"), "stop", "Stop");
      setIconButton(state.panelEl?.querySelector(".sts-close"), "close", "");
    }
    function setIconButton(button, iconName, label) {
      const iconNode = ICONS[iconName];
      if (!button || !iconNode) return;
      if (button.dataset.iconReady === iconName && button.dataset.iconLabel === label) {
        return;
      }
      const icon = createFilledIcon(iconNode);
      if (!icon) return;
      icon.setAttribute("aria-hidden", "true");
      icon.classList.add("sts-icon");
      button.textContent = "";
      button.append(icon);
      if (label) button.append(document.createTextNode(label));
      button.dataset.iconReady = iconName;
      button.dataset.iconLabel = label;
    }
    function showPanel() {
      const el = ensurePanel();
      el.style.display = "block";
      setTimeout(() => el.classList.add("sts-visible"), 10);
    }
    function hidePanel() {
      state.panelEl?.classList.remove("sts-visible");
    }
    function setDownloadStatus(message) {
      const status = ensurePanel().querySelector("#sts-stream-status");
      if (status) status.textContent = message || "";
    }
    function clearDownloadStatus() {
      setDownloadStatus("");
    }
    function setRunning(isRunning) {
      state.isRunning = isRunning;
      state.panelEl?.classList.toggle("is-loading", isRunning);
      state.panelEl?.querySelectorAll("[data-run]").forEach((button) => {
        button.toggleAttribute("disabled", isRunning);
      });
      state.panelEl?.querySelector(".sts-stop")?.toggleAttribute("disabled", !isRunning);
      if (isRunning)
        state.panelEl?.querySelector(".sts-copy")?.setAttribute("disabled", "true");
    }
    function renderMode(mode = "home") {
      const panel = ensurePanel();
      const content = panel.querySelector("#sts-content");
      const compose = panel.querySelector("#sts-compose");
      if (!content || !compose) return;
      state.currentMode = mode;
      state.outputEl = null;
      state.lastAnswer = "";
      panel.classList.toggle("sts-is-home", mode === "home");
      const title = panel.querySelector(".sts-back");
      if (title) {
        if (mode === "home") {
          title.textContent = "Local AI";
          delete title.dataset.iconReady;
          delete title.dataset.iconLabel;
        } else {
          setIconButton(title, "back", getModeTitle(mode));
        }
      }
      panel.querySelector(".sts-copy")?.setAttribute("disabled", "true");
      panel.querySelector(".sts-stop")?.setAttribute("disabled", "true");
      if (mode === "home") {
        content.innerHTML = `
        <div class="sts-mode-grid">
          <button class="sts-mode" type="button" data-mode="ask">Ask</button>
          <button class="sts-mode" type="button" data-mode="summarize">Summarize</button>
        </div>
      `;
        compose.innerHTML = "";
        content.querySelectorAll("[data-mode]").forEach((button) => {
          button.addEventListener("click", () => renderMode(button.dataset.mode));
        });
        return;
      }
      if (mode === "summarize") {
        compose.innerHTML = "";
        runQuickAction("summarize-page");
        return;
      }
      if (mode === "ask") {
        renderChatTranscript();
      } else {
        content.innerHTML = "";
      }
      compose.innerHTML = getModeForm(mode);
      trackTextEntryElement(compose.querySelector("textarea"));
      compose.querySelector("form")?.addEventListener("submit", onModeSubmit);
      const newSessionButton = compose.querySelector(".sts-new-session");
      if (newSessionButton) {
        setIconButton(newSessionButton, "newSession", "");
        newSessionButton.addEventListener("click", startNewAskSession);
      }
      syncAskSessionButton();
      compose.querySelector("textarea")?.addEventListener("keydown", onTextareaKeydown);
      compose.querySelector("[data-run='summary-page']")?.addEventListener("click", () => runQuickAction("summarize-page"));
      compose.querySelector("[data-run='summary-selection']")?.addEventListener("click", () => runQuickAction("summarize-selection"));
      compose.querySelector("textarea")?.focus();
    }
    function getModeTitle(mode) {
      return {
        ask: "Ask",
        summarize: "Summarize"
      }[mode] || "Assistant";
    }
    function getModeForm(mode) {
      if (mode === "ask") {
        return `
        <form class="sts-mode-form">
          <div class="sts-ask-grid">
            <textarea id="sts-question" rows="1" placeholder="Ask..."></textarea>
          </div>
          <div class="sts-ask-actions">
            <button class="sts-btn sts-btn--tinted" data-run="ask" type="submit">Ask</button>
            <button class="sts-btn sts-btn--icon sts-new-session" type="button" aria-label="Start new session" title="Start new session"></button>
          </div>
        </form>
      `;
      }
      if (mode === "summarize") {
        return "";
      }
      return "";
    }
    function setOutputShell(label = "Thinking") {
      const content = ensurePanel().querySelector("#sts-content");
      if (!content) return null;
      content.innerHTML = `
      <div class="sts-turn-label">${label}</div>
      <div class="sts-stream-shell">
        <div class="sts-stream-status" id="sts-stream-status" aria-live="polite"></div>
        <div class="sts-content-md sts-stream-text" id="sts-stream-text" aria-live="polite"></div>
      </div>
    `;
      state.outputEl = content.querySelector("#sts-stream-text");
      return state.outputEl;
    }
    function renderOutputText(text, format = "markdown") {
      return format === "markdown" ? renderMarkdown(text) : renderPlainText(text);
    }
    function setOutputText(text, label = "Result", format = "markdown") {
      const content = ensurePanel().querySelector("#sts-content");
      if (!content) return;
      content.innerHTML = `
      <div class="sts-turn-label">${escapeHtml2(label)}</div>
      <div class="sts-content-md">${renderOutputText(text, format)}</div>
    `;
    }
    function appendOutputChunk(chunk, format = "markdown") {
      appendStreamingChunk(chunk, format);
    }
    function appendStreamingChunk(chunk, format = "markdown") {
      if (!state.outputEl || !chunk) return;
      clearDownloadStatus();
      state.streamBuffer += chunk;
      if (format === "markdown") {
        scheduleStreamingRender();
        return;
      }
      state.outputEl.textContent += chunk;
      scrollContentToBottom();
    }
    function scheduleStreamingRender() {
      if (state.streamRenderFrame !== null) return;
      state.streamRenderFrame = requestAnimationFrame(() => {
        state.streamRenderFrame = null;
        if (!state.outputEl) return;
        state.outputEl.innerHTML = renderMarkdown(state.streamBuffer);
        scrollContentToBottom();
      });
    }
    function cancelStreamingRender() {
      if (state.streamRenderFrame === null) return;
      cancelAnimationFrame(state.streamRenderFrame);
      state.streamRenderFrame = null;
    }
    function scrollContentToBottom() {
      const content = ensurePanel().querySelector("#sts-content");
      if (content) content.scrollTop = content.scrollHeight;
    }
    function setError(message) {
      const help = [
        "Chrome setup checklist:",
        "1. Use Chrome/Chrome Canary on desktop.",
        "2. Enable chrome://flags/#optimization-guide-on-device-model.",
        "3. Enable chrome://flags/#prompt-api-for-gemini-nano or chrome://flags/#prompt-api-for-gemini-nano-multimodal-input when present.",
        "4. Relaunch Chrome and check chrome://on-device-internals for model status.",
        "5. Some APIs require an origin-trial token for chrome-extension://YOUR_EXTENSION_ID."
      ].join("\n");
      const content = ensurePanel().querySelector("#sts-content");
      if (!content) return;
      content.innerHTML = `
      <div class="sts-error">${escapeHtml2(message)}</div>
      <pre class="sts-help">${escapeHtml2(help)}</pre>
    `;
    }
    function escapeHtml2(value) {
      return String(value || "").replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;").replace(/'/g, "&#039;");
    }
    async function copyAnswer() {
      const copyBtn = state.panelEl?.querySelector(".sts-copy");
      const text = state.lastAnswer || state.panelEl?.querySelector("#sts-content")?.innerText || "";
      if (!copyBtn || !text) return;
      try {
        await navigator.clipboard.writeText(text);
        setIconButton(copyBtn, "copy", "Copied");
      } catch (_) {
        setIconButton(copyBtn, "copy", "Retry");
      } finally {
        setTimeout(() => {
          setIconButton(copyBtn, "copy", "Copy");
        }, 1300);
      }
    }
    function stopCurrentRun() {
      state.activeController?.abort();
      state.activeController = null;
      state.outputEl = null;
      state.streamBuffer = "";
      cancelStreamingRender();
      setRunning(false);
      setDownloadStatus("");
    }
    function startNewAskSession() {
      if (state.isRunning) stopCurrentRun();
      try {
        state.languageSession?.destroy?.();
      } catch (_) {
      }
      state.languageSession = null;
      state.chatMessages = [];
      state.outputEl = null;
      state.streamBuffer = "";
      cancelStreamingRender();
      state.lastAnswer = "";
      clearDownloadStatus();
      state.panelEl?.querySelector(".sts-copy")?.setAttribute("disabled", "true");
      const input = state.panelEl?.querySelector("#sts-question");
      if (input) input.value = "";
      renderChatTranscript();
      input?.focus();
    }
    function syncAskSessionButton() {
      const actions = state.panelEl?.querySelector(".sts-ask-actions");
      const button = state.panelEl?.querySelector(".sts-new-session");
      const hasSession = state.chatMessages.length > 0;
      actions?.classList.toggle("sts-has-session", hasSession);
      button?.setAttribute("aria-hidden", String(!hasSession));
      if (button) {
        if (hasSession) {
          button.removeAttribute("tabindex");
        } else {
          button.setAttribute("tabindex", "-1");
        }
      }
    }
    function onModeSubmit(event) {
      event.preventDefault();
      const input = state.panelEl?.querySelector("#sts-question");
      const question = cleanText(input?.value || "");
      const mode = state.currentMode;
      if (mode === "ask") {
        if (!question) return;
        input.value = "";
        runAssistantQuestion(question);
        return;
      }
    }
    function onTextareaKeydown(event) {
      if (event.key !== "Enter" || event.shiftKey) return;
      event.preventDefault();
      event.currentTarget?.form?.requestSubmit();
    }
    function openAssistant({ mode = "auto", prompt = "" } = {}) {
      state.selectionText = getSelectionText() || state.selectionText;
      showPanel();
      renderMode(
        mode === "selection" || mode === "page" ? "ask" : mode === "auto" ? "home" : mode
      );
      const input = state.panelEl?.querySelector("#sts-question");
      if (input && prompt) {
        input.value = prompt;
        input.focus();
      } else {
        input?.focus();
      }
      hideTooltip();
    }
    async function runQuickAction(action) {
      await ensureConfig();
      state.selectionText = getSelectionText() || state.selectionText;
      showPanel();
      prepareQuickActionMode("summarize");
      if (action === "summarize-page") {
        const summaryFormat = getSummaryConfig("page").format;
        await runTask(
          "Page summary",
          (emit) => summarizeText(getPageContext().text, "page", emit),
          summaryFormat
        );
        return;
      }
      if (action === "summarize-selection") {
        const text = state.selectionText;
        if (!text)
          return setError("Select text first, then use Selection summary.");
        const summaryFormat = getSummaryConfig("selection").format;
        await runTask(
          "Selection summary",
          (emit) => summarizeText(
            truncateText(text, MAX_SELECTION_CHARS),
            "selection",
            emit
          ),
          summaryFormat
        );
        return;
      }
    }
    function prepareQuickActionMode(mode) {
      const panel = ensurePanel();
      const compose = panel.querySelector("#sts-compose");
      state.currentMode = mode;
      state.outputEl = null;
      state.lastAnswer = "";
      panel.classList.toggle("sts-is-home", false);
      const title = panel.querySelector(".sts-back");
      if (title) setIconButton(title, "back", getModeTitle(mode));
      panel.querySelector(".sts-copy")?.setAttribute("disabled", "true");
      panel.querySelector(".sts-stop")?.setAttribute("disabled", "true");
      if (compose) compose.innerHTML = "";
    }
    async function runAssistantQuestion(question) {
      await ensureConfig();
      if (state.isRunning) stopCurrentRun();
      const context = getChatPageContext();
      const askConfig = state.config.ask;
      const userMessage = { role: "user", content: question };
      state.chatMessages.push(userMessage);
      const assistantMessage = { role: "assistant", content: "" };
      state.chatMessages.push(assistantMessage);
      renderChatTranscript();
      const prompt = [
        "Answer the user's latest question using the provided page context and conversation history when relevant.",
        "Be direct, note uncertainty, and do not invent facts not present in the context.",
        "Answer in the same language as the user's question.",
        "Treat conversation history as context for follow-up questions, but treat the page context as the source of truth for page facts.",
        `Answer style: ${askConfig.style}.`,
        `Output format: ${askConfig.format === "markdown" ? "Markdown" : "plain text"}.`,
        "",
        `Context source: ${context.label}`,
        context.text ? `Context:
${context.text}` : "Context: none",
        "",
        "Conversation history:",
        buildConversationHistoryPrompt(state.chatMessages.slice(0, -2)),
        "",
        `Latest question:
${question}`
      ].join("\n");
      await runChatTask(
        assistantMessage,
        (emit) => promptLanguageModel(prompt, emit)
      );
    }
    function renderChatTranscript() {
      const content = ensurePanel().querySelector("#sts-content");
      if (!content) return;
      if (!state.chatMessages.length) {
        content.innerHTML = `<div class="sts-empty"></div>`;
        syncAskSessionButton();
        return;
      }
      content.innerHTML = `
      <div class="sts-chat" aria-live="polite">
        ${state.chatMessages.map(renderChatMessage).join("")}
      </div>
    `;
      syncAskSessionButton();
      state.outputEl = content.querySelector(
        "[data-streaming='true'] .sts-message-text"
      );
      content.scrollTop = content.scrollHeight;
    }
    function renderChatMessage(message) {
      const isUser = message.role === "user";
      const label = isUser ? "You" : "Local AI";
      const content = message.content || "";
      const streamingAttr = !isUser && !message.content ? ' data-streaming="true"' : "";
      const renderedContent = isUser ? renderPlainText(content) : renderOutputText(content, state.config.ask.format);
      return `
      <div class="sts-message sts-message--${isUser ? "user" : "assistant"}"${streamingAttr}>
        <div class="sts-message-role">${label}</div>
        <div class="sts-content-md sts-message-text">${renderedContent}</div>
      </div>
    `;
    }
    async function runChatTask(assistantMessage, producer) {
      state.activeController = new AbortController();
      state.lastAnswer = "";
      state.streamBuffer = "";
      setRunning(true);
      const startedAt = performance.now();
      let out = "";
      try {
        out = await producer((chunk) => {
          const text = String(chunk || "");
          out += text;
          assistantMessage.content = out;
          appendChatChunk(text, state.config.ask.format);
        });
        assistantMessage.content = normalizeGeneratedOutput(out);
        state.lastAnswer = assistantMessage.content;
        renderChatTranscript();
        if (state.lastAnswer) {
          state.panelEl?.querySelector(".sts-copy")?.removeAttribute("disabled");
        }
        const seconds = Math.max(0.05, (performance.now() - startedAt) / 1e3);
        const cps = state.lastAnswer.length / seconds;
        if (Number.isFinite(cps) && cps > 0) savePerformanceMetrics(cps);
      } catch (error) {
        if (error?.name === "AbortError") {
          assistantMessage.content = normalizeGeneratedOutput(out) || "Stopped.";
          state.lastAnswer = assistantMessage.content;
          renderChatTranscript();
        } else {
          state.chatMessages.pop();
          setError(
            error instanceof Error ? error.message : "The assistant could not complete that request."
          );
        }
      } finally {
        setRunning(false);
        clearDownloadStatus();
        state.streamBuffer = "";
        cancelStreamingRender();
        state.activeController = null;
      }
    }
    function appendChatChunk(chunk, format = "markdown") {
      appendStreamingChunk(chunk, format);
    }
    function buildConversationHistoryPrompt(messages) {
      const lines = messages.map((message) => {
        const role = message.role === "user" ? "User" : "Assistant";
        return `${role}: ${message.content}`;
      });
      const history = cleanText(lines.join("\n\n"));
      return history ? truncateText(history, MAX_CHAT_HISTORY_CHARS) : "No previous messages.";
    }
    async function runTask(label, producer, format = "markdown") {
      if (state.isRunning) stopCurrentRun();
      state.activeController = new AbortController();
      state.lastAnswer = "";
      state.streamBuffer = "";
      setRunning(true);
      const surfaceEl = setOutputShell(label);
      const startedAt = performance.now();
      let out = "";
      try {
        if (surfaceEl instanceof HTMLElement) surfaceEl.textContent = "";
        out = await producer((chunk) => {
          const text = String(chunk || "");
          out += text;
          appendOutputChunk(text, format);
        });
        state.lastAnswer = normalizeGeneratedOutput(out);
        setOutputText(state.lastAnswer, label, format);
        if (state.lastAnswer) {
          state.panelEl?.querySelector(".sts-copy")?.removeAttribute("disabled");
        }
        const seconds = Math.max(0.05, (performance.now() - startedAt) / 1e3);
        const cps = state.lastAnswer.length / seconds;
        if (Number.isFinite(cps) && cps > 0) savePerformanceMetrics(cps);
      } catch (error) {
        if (error?.name === "AbortError") {
          setOutputText(
            normalizeGeneratedOutput(out) || "Stopped.",
            label,
            format
          );
        } else {
          setError(
            error instanceof Error ? error.message : "The assistant could not complete that request."
          );
        }
      } finally {
        setRunning(false);
        clearDownloadStatus();
        state.streamBuffer = "";
        cancelStreamingRender();
        state.activeController = null;
      }
    }
    function normalizeGeneratedOutput(text) {
      return String(text || "").trim();
    }
    function getPageContext() {
      const title = cleanText(document.title);
      const url = location.href;
      const text = extractReadablePageText();
      state.pageContext = {
        label: "page",
        text: truncateText(
          [title && `Title: ${title}`, `URL: ${url}`, text].filter(Boolean).join("\n\n"),
          MAX_CONTEXT_CHARS
        )
      };
      return state.pageContext;
    }
    function getChatPageContext() {
      if (!state.chatContext) state.chatContext = getPageContext();
      return state.chatContext;
    }
    function extractReadablePageText() {
      try {
        const article = new import_readability.Readability(document.cloneNode(true), {
          keepClasses: false
        }).parse();
        const readabilityText = cleanText(article?.textContent || "");
        if (readabilityText.length > 400) return readabilityText;
      } catch (_) {
      }
      const selectors = [
        "article",
        "main",
        "[role='main']",
        ".article",
        ".post",
        ".entry-content",
        ".content",
        "#content"
      ];
      const candidates = Array.from(
        document.querySelectorAll(selectors.join(","))
      );
      candidates.push(document.body);
      let best = document.body;
      let bestScore = -Infinity;
      for (const candidate of candidates) {
        if (!(candidate instanceof HTMLElement)) continue;
        const text2 = cleanText(candidate.innerText || "");
        if (text2.length < 200) continue;
        const linksText = Array.from(candidate.querySelectorAll("a")).map((link) => link.innerText || "").join(" ");
        const linkDensity = linksText.length / Math.max(text2.length, 1);
        const paragraphCount = candidate.querySelectorAll("p, li").length;
        const semanticBonus = /^(ARTICLE|MAIN)$/i.test(candidate.tagName) || candidate.getAttribute("role") === "main" ? 800 : 0;
        const score = text2.length + paragraphCount * 80 + semanticBonus - linkDensity * 2200;
        if (score > bestScore) {
          bestScore = score;
          best = candidate;
        }
      }
      const clone = best.cloneNode(true);
      if (!(clone instanceof HTMLElement))
        return cleanText(document.body.innerText || "");
      clone.querySelectorAll(
        [
          "script",
          "style",
          "noscript",
          "template",
          "svg",
          "canvas",
          "iframe",
          "nav",
          "footer",
          "header",
          "aside",
          "form",
          "button",
          "input",
          "select",
          "textarea",
          "[hidden]",
          "[aria-hidden='true']",
          "[role='navigation']",
          "[role='banner']",
          "[role='contentinfo']",
          "[class*='nav' i]",
          "[id*='nav' i]",
          "[class*='menu' i]",
          "[id*='menu' i]",
          "[class*='footer' i]",
          "[id*='footer' i]",
          "[class*='sidebar' i]",
          "[id*='sidebar' i]",
          "[class*='advert' i]",
          "[id*='advert' i]",
          "[class*='cookie' i]",
          "[id*='cookie' i]",
          "[class*='related' i]",
          "[id*='related' i]"
        ].join(",")
      ).forEach((node) => node.remove());
      const blocks = Array.from(
        clone.querySelectorAll("h1,h2,h3,p,li,blockquote,pre")
      ).map((node) => cleanText(node.innerText || node.textContent || "")).filter((text2) => text2.length > 24);
      const text = blocks.length ? blocks.join("\n\n") : cleanText(clone.innerText || clone.textContent || "");
      return text || cleanText(document.body.innerText || "");
    }
    async function summarizeText(text, source, emit) {
      await ensureConfig();
      const input = truncateText(
        text,
        source === "page" ? MAX_CONTEXT_CHARS : MAX_SELECTION_CHARS
      );
      if (!input) throw new Error("There is no readable text to summarize.");
      const summaryConfig = getSummaryConfig(source);
      const summaryContext = [
        summaryConfig.instructions,
        getFormatInstruction(summaryConfig.format)
      ].filter(Boolean).join("\n");
      if (summaryConfig.format === "plain-text") {
        return promptLanguageModel(
          buildSummaryFallbackPrompt(input, source, summaryConfig),
          emit
        );
      }
      if ("Summarizer" in self) {
        try {
          const summarizer = await createBuiltInApi("Summarizer", {
            type: summaryConfig.type,
            format: summaryConfig.format,
            length: summaryConfig.length,
            sharedContext: "Summarize web reading material for a user who wants the useful ideas, not site chrome."
          });
          return await collectStreamOrValue(
            summarizer.summarizeStreaming?.(input, {
              context: summaryContext,
              signal: state.activeController?.signal
            }),
            () => summarizer.summarize(input, {
              context: summaryContext,
              signal: state.activeController?.signal
            }),
            emit
          );
        } catch (error) {
          setDownloadStatus("Using the assistant model instead.");
        }
      }
      return promptLanguageModel(
        buildSummaryFallbackPrompt(input, source, summaryConfig),
        emit
      );
    }
    function getFormatInstruction(format) {
      if (format === "plain-text") {
        return "Use plain text only. Do not use Markdown syntax, headings, bullets, numbered lists, bold, links, tables, or code fences.";
      }
      return "Use Markdown only where it improves readability.";
    }
    function getSummaryConfig(source) {
      return source === "selection" ? state.config.summarize.selection : state.config.summarize.page;
    }
    function buildSummaryFallbackPrompt(input, source, config) {
      const typeInstruction = getTypeInstruction(config);
      const lengthInstruction = getLengthInstruction(config.length, config.type);
      return [
        `Summarize this ${source} using only the requested output.`,
        typeInstruction,
        lengthInstruction,
        `Output format: ${config.format === "markdown" ? "Markdown" : "plain text"}.`,
        getFormatInstruction(config.format),
        config.instructions,
        "Return only the final summary. Do not include analysis, drafts, alternatives, preambles, or a second summary.",
        "",
        "Source text:",
        input
      ].join("\n");
    }
    function getTypeInstruction(config) {
      if (config.format === "plain-text" && config.type === "key-points") {
        return "Cover the key points in compact prose. Do not format the response as a list.";
      }
      return {
        "key-points": "Write the key points only.",
        tldr: "Write one TL;DR only. It must be a compact final answer, not a longer summary followed by a TL;DR.",
        teaser: "Write one short teaser only.",
        headline: "Write one headline only."
      }[config.type] || `Use summary type: ${config.type}.`;
    }
    function getLengthInstruction(length, type) {
      if (type === "headline") return "Length: one line, no more than 18 words.";
      if (type === "teaser")
        return "Length: one sentence, no more than 30 words.";
      if (type === "tldr") {
        return length === "long" ? "Length: one paragraph, no more than 90 words." : length === "medium" ? "Length: one paragraph, no more than 60 words." : "Length: one or two sentences, no more than 40 words.";
      }
      return {
        short: "Length: no more than 60 words.",
        medium: "Length: no more than 120 words.",
        long: "Length: no more than 220 words."
      }[length] || `Length: ${length}.`;
    }
    async function promptLanguageModel(prompt, emit) {
      const session = await ensureLanguageSession();
      let out = "";
      if (session.promptStreaming) {
        const stream = session.promptStreaming(prompt, {
          signal: state.activeController?.signal
        });
        for await (const chunk of stream) {
          const text = String(chunk || "");
          out += text;
          emit?.(text);
        }
        if (out) return out;
      }
      return String(
        await session.prompt(prompt, { signal: state.activeController?.signal })
      );
    }
    async function ensureLanguageSession() {
      if (state.languageSession) return state.languageSession;
      if (!("LanguageModel" in self)) {
        throw new Error(
          "Prompt API is not exposed as LanguageModel in this Chrome profile."
        );
      }
      const availabilityOptions = await getFirstAvailableOptions(
        "LanguageModel",
        LANGUAGE_MODEL_OPTION_FALLBACKS
      );
      const options = {
        ...availabilityOptions,
        initialPrompts: [
          {
            role: "system",
            content: "You are a compact AI assistant for web consumption. Answer questions from page context, summarize carefully, and say when the context is insufficient."
          }
        ],
        monitor: createMonitor("Prompt"),
        signal: state.activeController?.signal
      };
      state.languageSession = await LanguageModel.create(options);
      state.languageSession.addEventListener?.("contextoverflow", () => {
        setDownloadStatus("Context trimmed");
      });
      return state.languageSession;
    }
    async function collectStreamOrValue(stream, fallback, emit) {
      let out = "";
      if (stream) {
        for await (const chunk of stream) {
          const text = String(chunk || "");
          out += text;
          emit?.(text);
        }
      }
      if (out) return out;
      return String(await fallback());
    }
    async function createBuiltInApi(name, options = {}) {
      if (!(name in self))
        throw new Error(`${name} API is not supported in this Chrome profile.`);
      const mergedOptions = {
        ...options,
        monitor: createMonitor(name, { showInitialComplete: false }),
        signal: state.activeController?.signal
      };
      await assertAvailable(name, options);
      return await self[name].create(mergedOptions);
    }
    function createMonitor(label, { showInitialComplete = false } = {}) {
      let hasShownProgress = false;
      return (monitor) => {
        monitor.addEventListener("downloadprogress", (event) => {
          const progress = Math.round((event.loaded || 0) * 100);
          if (progress >= 100 && !hasShownProgress && !showInitialComplete) {
            return;
          }
          hasShownProgress = true;
          setDownloadStatus(getModelLoadingMessage(label, progress));
        });
      };
    }
    function getModelLoadingMessage(label, progress) {
      const safeProgress = Math.max(0, Math.min(100, progress));
      const modelName = label === "Summarizer" ? "summarizer model" : "assistant model";
      if (safeProgress >= 100) return `Thinking...`;
      return `Loading the model into memory... ${safeProgress}%`;
    }
    async function assertAvailable(name, options = {}) {
      const api = self[name];
      if (!api?.availability) return;
      const availability = await getAvailability(name, options);
      if (availability === "unavailable") {
        throw new Error(`${name} is unavailable on this device/profile.`);
      }
      if (availability === "downloading") {
        setDownloadStatus(`${name} downloading`);
      }
    }
    async function getFirstAvailableOptions(name, optionCandidates = [{}]) {
      const errors = [];
      for (const options of optionCandidates) {
        try {
          const availability = await getAvailability(name, options, false);
          if (availability !== "unavailable") return options;
          errors.push(`${describeOptions(options)}: unavailable`);
        } catch (error) {
          errors.push(
            `${describeOptions(options)}: ${error instanceof Error ? error.message : "availability failed"}`
          );
        }
      }
      throw new Error(
        `${name} is unavailable with multilingual, English-only, and default options. ${errors.join("; ")}`
      );
    }
    async function getAvailability(name, options = {}, allowDefaultFallback = true) {
      const api = self[name];
      if (!api?.availability) return "available";
      let availability;
      try {
        availability = await api.availability(options);
      } catch (error) {
        if (!allowDefaultFallback || Object.keys(options).length === 0)
          throw error;
        availability = await api.availability();
      }
      return availability;
    }
    function describeOptions(options = {}) {
      if (!Object.keys(options).length) return "default";
      return JSON.stringify(options);
    }
    async function showApiStatus() {
      showPanel();
      const rows = await Promise.all(
        API_NAMES.map(async (name) => {
          if (!(name in self)) return { name, status: "not exposed" };
          try {
            const api = self[name];
            const status = api.availability ? await api.availability(API_AVAILABILITY_OPTIONS[name]) : "exposed";
            return { name, status };
          } catch (error) {
            return {
              name,
              status: error instanceof Error ? error.message : "check failed"
            };
          }
        })
      );
      const content = ensurePanel().querySelector("#sts-content");
      if (!content) return;
      content.innerHTML = `
      <div class="sts-turn-label">Built-in AI APIs</div>
      <div class="sts-api-grid">
        ${rows.map((row) => `<div class="sts-api-row"><strong>${escapeHtml2(row.name)}</strong><span>${escapeHtml2(row.status)}</span></div>`).join("")}
      </div>
      <pre class="sts-help">${escapeHtml2("Enable flags at chrome://flags, relaunch Chrome, then use Check APIs again. For origin-trial-only APIs, register chrome-extension://YOUR_EXTENSION_ID and add the token to the manifest.")}</pre>
    `;
    }
    function onSelectionChange() {
      const text = getSelectionText();
      state.selectionText = text;
      if (state.isSelectingWithPointer) return hideTooltip();
      if (!text || countWords(text) < state.minWords) return hideTooltip();
      const sel = window.getSelection();
      if (!sel?.rangeCount || sel.isCollapsed) return hideTooltip();
      const rect = sel.getRangeAt(0).getBoundingClientRect();
      if (rect && rect.width >= 0 && rect.height >= 0) {
        state.selectionText = text;
        showTooltipAt(rect);
      } else {
        hideTooltip();
      }
    }
    function isSelectionInView(rect) {
      const vx = window.scrollX;
      const vy = window.scrollY;
      const rTop = vy + rect.top;
      const rBottom = vy + rect.bottom;
      const rLeft = vx + rect.left;
      const rRight = vx + rect.right;
      return rBottom >= vy && rTop <= vy + window.innerHeight && rRight >= vx && rLeft <= vx + window.innerWidth;
    }
    function updateTooltipPositionIfNeeded() {
      const text = getSelectionText();
      if (!text || countWords(text) < state.minWords) return hideTooltip();
      const sel = window.getSelection();
      if (!sel?.rangeCount || sel.isCollapsed) return hideTooltip();
      const rect = sel.getRangeAt(0).getBoundingClientRect();
      if (!rect || rect.width <= 0 || rect.height <= 0) return hideTooltip();
      return isSelectionInView(rect) ? showTooltipAt(rect) : hideTooltip();
    }
    function finishPointerSelection() {
      if (!state.isSelectingWithPointer) return;
      state.isSelectingWithPointer = false;
      setTimeout(onSelectionChange, 10);
    }
    document.addEventListener(
      "selectionchange",
      () => setTimeout(onSelectionChange, 10)
    );
    document.addEventListener("mousedown", (event) => {
      state.lastMouseX = event?.clientX ?? state.lastMouseX;
      state.lastMouseY = event?.clientY ?? state.lastMouseY;
      if (state.panelEl?.contains(event.target)) return;
      if (event.button === 0) state.isSelectingWithPointer = true;
      hideTooltip();
    });
    document.addEventListener(
      "mousemove",
      (event) => {
        state.lastMouseX = event?.clientX ?? state.lastMouseX;
        state.lastMouseY = event?.clientY ?? state.lastMouseY;
      },
      true
    );
    document.addEventListener(
      "mouseup",
      (event) => {
        state.lastMouseX = event?.clientX ?? state.lastMouseX;
        state.lastMouseY = event?.clientY ?? state.lastMouseY;
        finishPointerSelection();
      },
      true
    );
    window.addEventListener("blur", finishPointerSelection);
    document.addEventListener(
      "scroll",
      () => updateTooltipPositionIfNeeded(),
      true
    );
    window.addEventListener("resize", updateTooltipPositionIfNeeded);
    chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
      if (message?.type === "sts-open-assistant") {
        openAssistant({
          mode: message.mode || "auto",
          prompt: message.prompt || ""
        });
        sendResponse({ ok: true });
        return;
      }
      if (message?.type === "sts-summarize-page") {
        runQuickAction("summarize-page");
        sendResponse({ ok: true });
        return;
      }
      if (message?.type === "sts-ask-selection") {
        state.selectionText = cleanText(
          message.selectionText || getSelectionText()
        );
        openAssistant({ mode: "selection", prompt: message.prompt || "" });
        sendResponse({ ok: true });
        return;
      }
      if (message?.type === "sts-summarize-selection") {
        state.selectionText = cleanText(
          message.selectionText || getSelectionText()
        );
        runQuickAction("summarize-selection");
        sendResponse({ ok: true });
        return;
      }
    });
    installTextEntryFirewall();
    loadConfig();
  })();
})();
